// 全局变量
const api = "http://192.168.0.12:80"
const globalData = {
  "api": api,
  "access_token": "", // token
  "appId": "wx90a1e7a7ffa11168",
  "imgUrl": api + "/cloud-system/data/getResource/", // 图片路径
  "filerProductParam": { sysType: "1" }, // service 过滤产品列表
}
export function setGlobalData (key, val) {
  globalData[key] = val
}
export function getGlobalData (key) {
  return globalData[key]
}

