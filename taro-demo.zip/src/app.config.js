export default {
  pages: [
    'pages/index/index',  // 首页
    'pages/service/index', // 服务tab页
    'pages/product/index', // 商品详情页
    'pages/login/index', // 登录页
    'pages/testRouter/index', // 测试页
    'pages/detail/index', // 测试页
    'pages/personal/index', // 个人中心
    'pages/cart/index', // 购物车
  ],
  window: {
    backgroundTextStyle: 'light',
    navigationBarBackgroundColor: '#fff',
    navigationBarTitleText: '风数贵宾',
    navigationBarTextStyle: 'black',
  },
  tabBar: {
    color: "#666",
    selectedColor: "#458B74",
    backgroundColor: "#fafafa",
    borderStyle: 'black',
    list: [{
      "pagePath": "pages/index/index",
      "iconPath": "./assets/images/nav/home-on.png",
      "selectedIconPath": "./assets/images/nav/home-off.png",
      "text": "首页",
    },
      {
        "pagePath": "pages/service/index",
        "iconPath": "./assets/images/nav/service-on.png",
        "selectedIconPath": "./assets/images/nav/service-off.png",
        "text": "服务"
      },
      {
        "pagePath": "pages/index/index",
        "iconPath": "./assets/images/nav/apponit-on.png",
        "selectedIconPath": "./assets/images/nav/apponit-off.png",
        "text": "预约"
      },
      {
        "pagePath": "pages/personal/index",
        "iconPath": "./assets/images/nav/my-on.png",
        "selectedIconPath": "./assets/images/nav/my-off.png",
        "text": "我的"
      }
    ]}
}
