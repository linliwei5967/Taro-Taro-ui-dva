import indexModel from '../pages/index/model'
import loginModel from '../pages/login/model'

export default [
  indexModel,
  loginModel,
]
