import React, { Component } from 'react'
import Taro from '@tarojs/taro'
import { View, Text, Image } from '@tarojs/components'
import { ButtonItem } from '../../../components'
// import jump from '@utils/jump'
import homeIcon from './assets/home.png'
import serviceIcon from './assets/service.png'
import cartIcon from './assets/cart.png'
import './index.scss'

const NAV_LIST = [{
  key: 'home',
  img: homeIcon,
  url: '/pages/index/index'
}, {
  key: 'service',
  img: serviceIcon,
  url: '/pages/login/index'
}, {
  key: 'cart',
  img: cartIcon,
  url: '/pages/cart/index',
}]

// 详情底部添加购物车栏
export default class Footer extends Component {
  static defaultProps = {
    onAdd: () => {}
  }

  handleNav = (item) => {
    if (item.key === 'service') {
      Taro.showToast({
        title: '敬请期待',
        icon: 'none'
      })
    } else {
      jump({ url: item.url, method: 'switchTab' })
    }
  }

  handleBuy = () => {
    if(!Taro.getStorageSync("userId")){
      Taro.navigateTo({url: '/pages/login/index'})
      Taro.showToast({
        title: '请先登录',
        icon: 'none'
      })
    }
  }

  // 跳转页面
  toJumpPage = (url, index) => {
    index == 0 && Taro.switchTab({url: url})
    index != 0 && Taro.navigateTo({url: url})
  }

  render () {
    return (
      <View className='item-footer'>
        {NAV_LIST.map((item, index) => (
          <View
            key={item.key}
            className='item-footer__nav'
            onClick={(e)=>{this.toJumpPage(item.url, index)}}
          >
            <Image
              className='item-footer__nav-img'
              src={item.img}
            />
          </View>
        ))}
        <View className='item-footer__buy' onClick={this.handleBuy}>
          <Text className='item-footer__buy-txt'>立即购买</Text>
        </View>
        <ButtonItem
          type='primary'
          text='加入购物车'
          onClick={this.props.onChoose}
          compStyle={{
            width: Taro.pxTransform(235),
            height: Taro.pxTransform(100)
          }}
        />
      </View>
    )
  }
}
