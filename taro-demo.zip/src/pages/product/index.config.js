export default {
  navigationBarTitleText: '商品详情'
}
