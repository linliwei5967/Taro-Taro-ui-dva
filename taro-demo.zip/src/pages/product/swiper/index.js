import React, { Component } from 'react'
import Taro from '@tarojs/taro'
import { View, Text, Swiper, SwiperItem, Image } from '@tarojs/components'
import './index.scss'

export default class DSwiper extends Component {
  constructor (props) {
    super(props)
    this.state = {
      current: 1,
      duration: 500,
      interval: 5000,
      isCircular: true,
      isAutoplay: true,
      hasIndicatorDots: true,
    }
  }

  handleChange = (e) => {
    const { current } = e.detail
    this.setState({ current })
  }

  render () {
    const { swiperLsit } = this.props.product
    const { current, isAutoplay, duration, isCircular, interval, hasIndicatorDots } = this.state
    return (
      <View className='item-gallery'>
        <Swiper
          className='item-gallery__swiper'
          current={current}
          duration={duration}
          interval={interval}
          circular={isCircular}
          autoplay={isAutoplay}
          indicatorDots={hasIndicatorDots}
          onChange={this.handleChange}
        >
          {swiperLsit && swiperLsit.map((item, index) => (
            <SwiperItem
              key={index}
              className='item-gallery__swiper-item'
            >
              <Image
                className='item-gallery__swiper-item-img'
                src={item}
              />
            </SwiperItem>
          ))}
        </Swiper>
        <View className='item-gallery__indicator'>
          <Text className='item-gallery__indicator-txt'>
            {`${current + 1}/${swiperLsit.length}`}
          </Text>
        </View>
      </View>
    )
  }
}
