import Taro, { getCurrentInstance } from '@tarojs/taro'
import React, { Component } from 'react'
import { View, ScrollView } from '@tarojs/components'
import Footer from './footer/index'
import Swiper from './swiper/index'
import InfoBase from './infoBase/index'
import InfoParam from './infoParam/index'
import InfoImage from './infoImage/index'
import AddChooseInfo from './addChooseInfo/index'
import { AtFloatLayout } from "taro-ui"
import './index.scss'
import {getWindowHeight} from "../../utils/style";
import "taro-ui/dist/style/components/float-layout.scss";
import {Request} from "../../utils/request";


// 商品详情页
export default class Product extends Component {
  constructor(props) {
    super(props)
    this.state = {
      loaded: false,
      selected: {},
      product:{
        name:"严选礼品卡 1000元面值",
        simpleDesc:"高档、精致、省心的礼赠佳品",
        off: "99.9",
        activityPrice: 687.99,
        retailPrice: 999.9,
        tagList:[{
            tagName: "全球销量遥遥领先",
          }],
        swiperLsit:[ // 轮播
          "https://yanxuan-item.nosdn.127.net/55425f24345d01992d61a1646325ac94.png",
          "https://yanxuan-item.nosdn.127.net/11644dd3c9085574176a8dbf98d144af.jpg",
          "https://yanxuan-item.nosdn.127.net/d814ec65c4f99426ecae7c91bff4bb14.jpg",
        ],
        infoImageList:[ // 底部详情
          "https://yanxuan-item.nosdn.127.net/55425f24345d01992d61a1646325ac94.png",
          "https://yanxuan-item.nosdn.127.net/11644dd3c9085574176a8dbf98d144af.jpg",
          "https://yanxuan-item.nosdn.127.net/d814ec65c4f99426ecae7c91bff4bb14.jpg",
        ],
        smallImage:"https://yanxuan-item.nosdn.127.net/55425f24345d01992d61a1646325ac94.png",
        attrList:[{
            name: "适用人群",
            value: "老总 土豪",
          }, {
            name: "卡片性质",
            value: "超级会员白金卡",
          }, {
            name: "结算方式",
            value: "按人次 不足...按人次计算",
          },],
        isOpened: false, // 浮窗
      }
    }
    // this.productId = parseInt(this.$router.params.itemId)
  }

  componentDidMount() {
    const { bizId, sysType } = getCurrentInstance().router.params
    this.bizId = bizId
    this.sysType = sysType
    this.getDetail()
  }

  // // 接收路由传递参数
  // onLoad (options) {
  //  console.log(options)
  //   this.bizId = options.bizId
  //   this.sysType = options.sysType
  //   this.getDetail()
  // }

  // 获取产品详情
  getDetail = () =>{
    Request({
      url: '/cloud-vip-net/agreement/get-app-agreement-detail',
      method: 'get',
      data: {
        bizId: this.bizId,
        sysType: this.sysType,
      }
    }).then(res => {
        if(res.code == "200"){
          this.setState({
            product: res.data,
          })
        }
      })
  }

  // 选择商品属性 —> 弹窗
  onShowChoosePop = () => {
    this.setState({
      isOpened: true, // 浮窗打开
    })
  }

  render () {
    const { product, isOpened } = this.state
    return (
      <View className='product-container'>
        <ScrollView
          scrollY
          className='item__wrap'
          style={{ height: getWindowHeight(false) }}
        >
          <Swiper product={product}/>  {/*详情大图轮播模块*/}
          <InfoBase product={product}/> {/*商品名称、价格..*/}
          <InfoParam product={product}/> {/*商品参数*/}
          <InfoImage product={product}/> {/*商品详情图*/}
        </ScrollView>

        {/* NOTE Popup 一般的实现是 fixed 定位，但 RN 不支持，只能用 absolute，要注意引入位置 */}
        <AtFloatLayout
          isOpened={isOpened}
        >
          <AddChooseInfo
            product={product}
            selected={this.state.selected}
            onSelect={this.handleSelect}
          />
        </AtFloatLayout>

        <View className='item__footer'>
          <Footer onChoose={this.onShowChoosePop} />
        </View>
      </View>
    )
  }
}
