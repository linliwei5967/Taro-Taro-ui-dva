import React, { Component } from 'react'
import Taro from '@tarojs/taro'
import { View, Text } from '@tarojs/components'
import './index.scss'

// 商品参数
export default class InfoParam extends Component {
  render () {
    const { product } = this.props
    return (
      <View className='item-info-param'>
        <View className='item-info-param__title'>
          <Text className='item-info-param__title-txt'>商品参数</Text>
        </View>
        {product.attrList.map((item, index) => (
          <View key={index} className='item-info-param__item'>
            <Text className='item-info-param__item-name'>{item.name}</Text>
            <Text className='item-info-param__item-value'>{item.value}</Text>
          </View>
        ))}
      </View>
    )
  }
}
