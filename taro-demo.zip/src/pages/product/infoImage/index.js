import React, { Component } from 'react'
import Taro from '@tarojs/taro'
import { View, Image } from '@tarojs/components'
import './index.scss'

// 商品详情图
export default class InfoImage extends Component {
  render () {
    const { product } = this.props
    // const imgList = []
    // const reg = /<img.*?src="(.*?)".*?\/>/g
    // let res = null
    // while (res = reg.exec(html)) {
    //   imgList.push(res[1])
    // }

    return (
      <View className='item-detail'>
        {product.infoImageList.map((item, index) => (
          <Image
            key={index}
            className='item-detail__img'
            src={item}
            mode='widthFix'
          />
        ))}
      </View>
    )
  }
}
