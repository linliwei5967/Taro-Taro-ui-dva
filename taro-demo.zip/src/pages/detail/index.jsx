import React, { Component } from 'react'
import { View, Text } from '@tarojs/components'
import {AtButton, AtCalendar} from 'taro-ui'
import { getLatestTopic } from '../../utils/common'
import Taro from '@tarojs/taro'
import { AtAccordion, AtList, AtListItem } from 'taro-ui'
import "taro-ui/dist/style/components/calendar.scss";
import "taro-ui/dist/style/components/button.scss" // 按需引入
import './index.scss'
import "taro-ui/dist/style/components/accordion.scss";
import "taro-ui/dist/style/components/icon.scss";
import {getGlobalData} from "../../utils/global";

const app = Taro.getApp()
export default class Detail extends Component {
  constructor (props) {
    super(props)
    this.state = {
      open: true,
    }
  }

  async componentWillMount () {

  }

  componentDidMount () { }

  componentWillUnmount () { }

  componentDidShow () { }

  componentDidHide () { }

  handleNavigate = () =>{
    Taro.switchTab({
      url: '/pages/index/index'
    })
  }

  render () {
    return (
      <View className='index'>
        {console.log(getGlobalData("access_token"))}
        <AtButton type='primary' onClick={this.handleNavigate}>我是第detail页面</AtButton>
      </View>
    )
  }
}
