import React, { Component } from 'react'
import Taro from '@tarojs/taro'
import { View, Text, ScrollView } from '@tarojs/components'
// import { connect } from '@tarojs/redux'
// import * as actions from '@actions/user'
// import { dispatchCartNum } from '@actions/cart'
import Profile from './profile/index'
import Menu from './menu/index'
import Activity from './activity/index'
import './index.scss'
import {getWindowHeight} from "../../utils/style";
import {toAuthorize} from "../../utils/common";
import { AtModal } from 'taro-ui'

// @connect(state => state.user, { ...actions, dispatchCartNum })
export default class Personal extends Component {
  constructor(props) {
    super(props)
    this.state = {
      userInfo: {
        login: true,
        uid: '001',
        isOpened: false, // 退出提示
      },
    }
  }

  componentWillMount(){
    const userId = Taro.getStorageSync('userId')
    if(!userId){
      Taro.redirectTo({ url: '/pages/login/index' })
    }
  }

  componentDidMount(){
    // 获取用户信息
    Taro.getUserInfo({
      success: (res)=>{
        console.log(res)
        this.setState({
          userInfo: res.userInfo
        })
      }
    })
  }

  handleLogin = () => {
    Taro.navigateTo({
      url: '/pages/user-login/user-login'
    })
  }

  // 退出弹窗
  onExit = () =>{
    this.setState({
      isOpened: true
    })
  }

  // 退出取消
  onExitCancel = () =>{
    this.setState({
      isOpened: false
    })
  }

  // 退出确认
  onExitConfirm = () =>{
    Taro.redirectTo({
      url: '/pages/login/index'
    })
    Taro.clearStorageSync() // 清除所有缓存
    Taro.showToast({
      title: '已退出',
      icon: 'none',
    })
  }

  render () {
    const { userInfo, isOpened } = this.state
    return (
      <View className='user'>
        <ScrollView
          scrollY
          className='user__wrap'
          style={{ height: getWindowHeight(false) }}
        >
          <Profile userInfo={userInfo} />
          <Menu />
          {userInfo &&
            <View className='user__logout'  onClick={this.onExit}>
              <Text className={'iconfont icon-logout'} style={{fontSize: "16PX"}}/>
              <Text className='user__logout-txt'> &nbsp;退出</Text>
            </View>
          }
          <View className='user__empty' />
        </ScrollView>
        <View className='user__activity'>
          <Activity />
        </View>
        <AtModal
          isOpened={isOpened}
          // title='提示'
          cancelText='取消'
          confirmText='确认'
          // onClose={this.handleClose}
          onCancel={this.onExitCancel}
          onConfirm={this.onExitConfirm}
          content='确认退出?'
        />
      </View>
    )
  }
}

