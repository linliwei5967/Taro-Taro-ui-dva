import React, { Component } from 'react'
import Taro from '@tarojs/taro'
import { View, Text, Image } from '@tarojs/components'
// import jump from '@utils/jump'
import classNames from 'classnames'
import './index.scss'
import '../../../assets/icons/iconfont.css'

const MENU_LIST = [{
  key: 'credit',
  text: '我的账户',
  img: require('./assets/credit.png'),
  icon: "icon-yonghu-"
}, {
  key: 'pin',
  text: '我的会员卡',
  img: require('./assets/pin.png'),
  icon: 'icon-wodehuiyuanqia'
}, {
  key: 'bargain',
  text: '我的协议',
  img: require('./assets/bargain.png'),
  icon: 'icon-xinxirenzheng',
  size: '31PX'
}, {
  key: 'bargain',
  text: '我的银行卡',
  img: require('./assets/bargain.png'),
  icon: 'icon-yinhangka'
}, {
  key: 'service',
  text: '我的预约',
  img: require('./assets/service.png'),
  icon: 'icon-yiliaohangyedeICON-'
}, {
  key: 'red-packet',
  text: '我的优惠券',
  img: require('./assets/red-packet.png'),
  icon: 'icon-youhuiquan'
},{
  key: 'order',
  text: '我的订单',
  img: require('./assets/order.png'),
  icon: 'icon-dingdan',
  size: '26PX'
}, {
  key: 'gif-card',
  text: '常用信息',
  img: require('./assets/gif-card.png'),
  icon: 'icon-yixianshi-',
  size: '32PX'
},
// {
//   key: 'location',
//   text: '地址管理',
//   img: require('./assets/location.png'),
//   icon: 'icon-youhuiquan'
// }, {
//   key: 'safe',
//   text: '账号安全',
//   img: require('./assets/safe.png'),
//   icon: 'icon-youhuiquan'
// }, {
//   key: 'contact',
//   text: '联系客服',
//   img: require('./assets/contact.png'),
//   icon: 'icon-youhuiquan'
// }, {
//   key: 'feedback',
//   text: '用户反馈',
//   img: require('./assets/feedback.png'),
//   icon: 'icon-youhuiquan'
// }, {
//   key: 'help',
//   text: '帮助中心',
//   url: 'http://m.you.163.com/help',
//   img: require('./assets/help.png'),
//   icon: 'icon-youhuiquan'
// },
]
const COUNT_LINE = 3

export default class Menu extends Component {

  handleClick = (menu) => {
    // NOTE 时间关系，此处只实现帮助中心，用于演示多端 webview
    if (menu.key === 'help') {
      jump({ url: menu.url, title: menu.text })
    } else {
      Taro.showToast({
        title: '提示..',
        icon: 'error',
      })
    }
  }

  render () {
    return (
      <View className='user-menu'>
        {MENU_LIST.map((menu, index) => {
          // NOTE 不用伪元素选择器，需自行计算
          const nth = (index + 1) % COUNT_LINE === 0
          const lastLine = parseInt(index / COUNT_LINE) === parseInt(MENU_LIST.length / COUNT_LINE)
          return (
            <View
              key={menu.key}
              className={classNames(
                'user-menu__item',
                nth && 'user-menu__item--nth',
                lastLine && 'user-menu__item--last',
              )}
              onClick={(e)=>{this.handleClick(menu)}}
            >
              <Text className={'iconfont '+ menu.icon} style={{fontSize: menu.size}}/>
                {/*{menu.icon && menu.icon()}</Text>*/}
              {/*<Image className='user-menu__item-img' src={menu.img} />*/}
              <Text className='user-menu__item-txt'>{menu.text}</Text>
            </View>
          )
        })}
      </View>
    )
  }
}
