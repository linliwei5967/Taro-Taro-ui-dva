import React, { Component } from 'react'
import Taro from '@tarojs/taro'
import {View, Image, Text} from '@tarojs/components'
import pic from './assets/activity.png'
import picActive from './assets/activity-active.png'
import './index.scss'

export default class Activity extends Component {
  constructor(props) {
    super(props)
    this.state = {
      active: false
    }
  }
  timer = null

  componentDidMount() {
    this.timer = setInterval(() => {
      this.setState({ active: !this.state.active })
    }, 600)
  }

  componentWillUnmount() {
    if (this.timer) {
      clearInterval(this.timer)
    }
  }

  onClick =()=>{
    Taro.showToast({title: "提示.."})
  }

  render () {
    return (
      <View className='user-activity' onClick={this.onClick}>
        <Image
          className='user-activity__img'
          src={this.state.active ? picActive : pic}
        />
        {/*<Text className='user-activity__title'>优惠券</Text>*/}
      </View>
    )
  }
}
