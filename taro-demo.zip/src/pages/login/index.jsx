import React, { Component } from 'react'
import Taro from '@tarojs/taro'
import { View, Text, Form, Input, Label, Button, Image } from '@tarojs/components'
// import "taro-ui/dist/style/components/icon.scss";
// import "taro-ui/dist/style/components/button.scss" // 按需引入
import "taro-ui/dist/style/components/form.scss";
import "taro-ui/dist/style/components/icon.scss";
import { AtForm, AtInput, AtButton, AtIcon, AtDivider } from 'taro-ui'
import './index.scss'
import { Request } from "../../utils/request.js"
import {getGlobalData} from "../../utils/global";
import backImg1 from "../../assets/images/login-bg1.png"
import {connect} from "react-redux";

@connect(({ })=>{return {}})
export default class Login extends Component {
  constructor (props) {
    super(props)
    this.state = {
      phone: null,
      smsCode: null,
      isClickLogin: false, // 是否点击 -> 登录按钮
      isSendCode: false, // 是否点击 -> 验证码
      secondCount: 60, // 倒计时
      openId: getGlobalData('openId'), // 用户openId
    }
  }

  componentDidMount () { }

  componentWillUnmount () { }

  // 手机号 -> 输入
  onChangePhone = (value) => {
    this.setState({
        phone: value,
    })
  }

  // 验证码 -> 输入
  onChangeSmsCode = (value) => {
    this.setState({
        smsCode: value,
    })
  }

  // 短信验证码 -> 发送
  getSmsCode = () =>{
    if (this.state.isSendCode) return
    const { phone } = this.state
    if(!phone || phone.length != 11){
      Taro.showToast({title: '请完善信息', icon: 'none', mask: true})
      return
    }
    const { dispatch, params } = this.props // 接口
    dispatch({
      type: 'loginModel/getSmsCode',
      payload: {
        openId: "",
        phone: phone,
      }
    }).then(res => {
      if (res.code == "200") {
        this.setState({
          smsId: res.data.id,
          isClickLogin: false,
          isSendCode: true
        })
        // Taro.setStorageSync("checkCodeId", res.data.id)
      }
      this.toCount() // 重新获取倒计时
    })

  }

  // 开始倒计时
  toCount = () =>{
    const timer = setInterval(() => {  // 倒计时
      if (this.state.secondCount > 0) {
        this.setState({
          secondCount: this.state.secondCount - 1
        })
      } else {
        this.setState({
          secondCount: 60,
          isSendCode: false
        })
        clearInterval(timer)
      }
    }, 1000)
  }

  // 短信验证码 倒计时
  isGetCodeText = () =>{
    return this.state.isSendCode ? `${this.state.secondCount}s后重试` : '发送验证码'
  }

  // 手机号 ICON
  iConPhoneRender = () =>{
    return (
        <Label className={"login-icon-container"}>
          <AtIcon prefixClass='at-icon' value='iphone' className={"icon"}/>
          {/*<Label className={"text"}>手机</Label>*/}
        </Label>
      )
  }

  // 验证码 ICON
  iConMailRender = () =>{
    return (
        <Label className={"login-icon-container"}>
          <AtIcon prefixClass='at-icon' value='mail' className={"icon"} size={20}/>
          {/*<Label className={"text"}>验证码</Label>*/}
        </Label>
      )
  }

  // 登录
  onLogin = () => {
    const { phone, smsCode, openId, smsId } = this.state
    if(!phone || !smsCode){
      Taro.showToast({title: "请完善信息",icon: "none"})
      return
    }
    this.setState({isClickLogin: true})
    const { dispatch, params } = this.props // 短信登录
    dispatch({
      type: 'loginModel/onLogin',
      payload: {
        openId: openId,
        phone: phone,
        authCode: smsCode,
        smsId: smsId,
      }
    }).then(res => {
        this.setState({
          isClickLogin: false,
        },()=>{
          if (res.code == "200") {
            Taro.showToast({title: "登录成功"})
            Taro.setStorageSync('userId', res.data.id) // 存取用户id
            Taro.switchTab({url: '/pages/index/index'})
          }else {
            Taro.showToast({title: "验证码错误",icon: "none"})
          }
        })
    })
  }


  // 用户授权 获取openid
  toAuthorize = (res) => {
    if(res.detail.userInfo){ // 返回的信息中包含用户信息则证明用户允许获取信息授权
      // 保存用户信息微信登录
      // 可以通过 Taro.getSetting 先查询一下用户是否授权了 "scope.userInfo" 这个 scope
      Taro.authorize({
          scope: 'scope.record',
          success: function () {
            Taro.login({
              success: function (resLogin) {
                console.log('获取用户信息',resLogin)
                if (resLogin.code) {
                  Request({
                    url: `/cloud-vip-net/wechat/user/${getGlobalData('appId')}/login`,
                    method: 'get',
                    data: {
                      code: resLogin.code,
                    },
                  })
                } else {
                  console.log('登录失败！' + resLogin.errMsg)
                }
              }
            })
          }
        })
    } else {
      Taro.switchTab({url: '/pages/login/index'})
    }
  }

  render () {
    const { phone, smsCode, } = this.state
    const { isSendCode, isClickLogin } = this.state
    return (
      <View className='container login-container'>
        <View className="login-background-container">
          <image className="login-img" src={backImg1}/>
        </View>
        <AtForm
            // onSubmit={this.onLogin}
          >
          <View className="login-input-container">
            <AtInput
              name='phone'
              title={this.iConPhoneRender()}
              type='text'
              // clear={true}
              placeholder='请输入手机号'
              value={phone}
              onChange={this.onChangePhone}
            >
              {/*<AtIcon prefixClass='at-icon' value='iphone' size='30' color='#000'/>*/}
            </AtInput>
            <AtInput
              name='smsCode'
              title={this.iConMailRender()}
              border={false}
              type='phone'
              // clear={true}
              placeholder='请输入短信验证码'
              value={smsCode}
              onChange={this.onChangeSmsCode}
            >
              <View style={{color: isSendCode ? '#ab0f0a' : '', fontSize: '12px', width: '90px'}}
                    onClick={this.getSmsCode}>
                {this.isGetCodeText()}
              </View>
            </AtInput>
          </View>
          <View className='login-btn-container'>
              <AtButton className='btn' type="primary" loading={isClickLogin} onClick={this.onLogin}>登录</AtButton><br/>
              <AtButton className='btn' openType='getUserInfo' onGetUserInfo={this.toAuthorize}>点击授权</AtButton>
              <Text className='login-tips'>登录/注册即视为你同意《服务条款》</Text>
              {/*<AtDivider content='登录/注册即视为你同意《服务条款》'*/}
                         {/*fontSize={24}*/}
                         {/*fontColor={"rgba(201, 201, 201, 0.93)"}*/}
              {/*/>*/}
          </View>
        </AtForm>
      </View>
    )
  }
}
