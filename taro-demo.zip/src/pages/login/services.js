import {Request} from '../../utils/request'
import {getGlobalData} from "../../utils/global";

// 获取短信验证码
export async function getSmsCode(params) {
  return Request({url:`/cloud-vip-net/wechat/user/${getGlobalData("appId")}/app-send-sms`, method: 'postForm', data: params});
}

// 登录/注册
export async function onLogin(params) {
  return Request({url:`/cloud-vip-net/wechat/user/${getGlobalData("appId")}/app-login`, method: 'postForm', data: params});
}

