import {getSmsCode, onLogin} from "./services";

export default {
  namespace: 'loginModel',
  state: {

  },
  effects: {
    // 获取短信验证码
    * getSmsCode({payload}, {call, put}) {
      const res = yield call(getSmsCode, payload)
      const {data = {}} = res || {}
      return res
    },
    // 登录/注册
    * onLogin({payload}, {call, put}) {
      const res = yield call(onLogin, payload)
      const {data = {}} = res || {}
      return res
    },
  },
  reducers: {
    updateState(state, {payload}) {
      return {
        ...state,
        ...payload,
      };
    },
  },
}
