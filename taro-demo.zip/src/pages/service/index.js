import Taro, { getCurrentInstance } from '@tarojs/taro'
import React, { Component } from 'react'
import {View, ScrollView, Text} from '@tarojs/components'
import { AtTabs, AtTabsPane, AtSearchBar, AtCard } from "taro-ui"
import {Request, setFilerProductParam} from "../../utils/request";
import NoticeBar from './noticebar/index'
import Conditions from './conditions/index'
import ProductList from './productList/index'
import './index.scss'
import {getGlobalData, setGlobalData} from "../../utils/global";

// 产品查询页
export default class Product extends Component {
  constructor(props) {
    super(props)
    this.state = {
      searchWord: "", // 查询条件
      current: 0,
      tabList: [{ title: '服务产品', }, { title: '会员卡' }],
      productList: [],
    }
  }

  componentDidMount() {
    const {  } = getCurrentInstance().router.params
    this.getList()
  }

  // 获取产品列表
  getList = () =>{
    Request({
      url: '/cloud-vip-net/agreementDefine/app-list',
      method: 'get',
      data: {...getGlobalData('filerProductParam')}
    }).then(res => {
        if(res.code == "200"){
          this.setState({
            productList: res.data
          })
        }
      })
  }

  // 切换tab
  onTabChange (stateName, value) {
    this.setState({
      [stateName]: value,
    })
    // setFilerProductParam('sysType', value + 1)
    setGlobalData('filerProductParam',{sysType: value + 1})
    this.getList()
  }

  // 查询条件
  onSearchChange =(value)=>{
    // this.state.searchWord = value
    this.setState({ searchWord: value })
    setFilerProductParam('searchWord', value)
  }

  // // 查询
  // onSearch =()=>{
  //   this.getList
  // }

  render () {
    const { tabList, current, productList } = this.state
    return (
      <View className='doc-page'>
        <View className='panel'>
          <View className='panel__content'>
            <AtTabs swipeable={false} current={current} tabList={tabList} onClick={this.onTabChange.bind(this, 'current')}>
              {tabList.map((item, index)=>{
                return (
                  <AtTabsPane current={current} index={index} >
                    <View className='tab-content'>
                      <NoticeBar />
                      <AtSearchBar
                        actionName='搜索'
                        showActionButton
                        value={this.state.searchWord}
                        onChange={this.onSearchChange.bind(this)}
                        onActionClick={this.getList}
                      />
                      <View className='conditions-panel'>
                        {/*<Text className='drawer-icon'> ∨</Text>*/}
                        {/*协议类型*/}
                        <Conditions
                          title={{key: '类型', value: 'agreementType'}}
                          param={{parentId: '1274986088013328385'}}
                          getProductList={this.getList}
                        />
                        {/*进出港*/}
                        <Conditions
                          title={{key: '进出港', value: 'direction'}}
                          param={{parentId: '1271688651458793474'}}
                          getProductList={this.getList}
                        />
                        {/*区域*/}
                        <Conditions
                          title={{key: '可用区域', value: 'areaCode'}}
                          param={{parentId: '1274986088013328385'}}
                          getProductList={this.getList}
                          // style={{ padding: "0 10rpx" }}
                          isAreaOption
                        />
                        {/*产品列表*/}
                        <ProductList
                          list={productList}
                        />
                      </View>
                    </View>
                  </AtTabsPane>
                )
              })}
              {/*<AtTabsPane current={current} index={1}>*/}
                {/*<View className='tab-content'>*/}
                  {/*<NoticeBar />*/}
                  {/*<AtSearchBar actionName='搜一下'/>*/}
                {/*</View>*/}
              {/*</AtTabsPane>*/}
            </AtTabs>
          </View>
        </View>
      </View>
    )
  }
}
