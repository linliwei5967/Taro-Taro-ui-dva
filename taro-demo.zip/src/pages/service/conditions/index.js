import Taro, { getCurrentInstance } from '@tarojs/taro'
import React, { Component } from 'react'
import { View } from '@tarojs/components'
import { AtTag } from 'taro-ui'
import './index.scss'
import {Request, setFilerProductParam} from "../../../utils/request";
import {getGlobalData, setGlobalData} from "../../../utils/global";

// 过滤条件
export default class Conditions extends Component {
  constructor(props) {
    super(props)
    this.state = {
      tagList: [
        { name: '全部', active: false },
        { name: '协议类型1', active: false },
        { name: '协议类型2', active: false },
      ],
    }
  }

  componentDidMount () {
    const { isAreaOption } = this.props
    isAreaOption && this.getAreaList()
    !isAreaOption && this.getList()
  }

  // 获取查询条件列表
  getList =()=>{
    const { param } = this.props
    Request({
      url: '/cloud-system/dict/child-list',
      method: 'get',
      data: {parentId: param.parentId},
    }).then(res =>{
      if(!res){return}
      if(res.code == 200){
        this.setState({
          tagList: res.data.records
        })
      }
    })
  }

  // 获取查询条件列表 (区域 特殊)
  getAreaList =()=>{
    const { param } = this.props
    Request({
      // url: '/cloud-vip/area/getPullDownList',
      url: '/cloud-vip-net/area/app-pulldown-list',
      method: 'get',
      data: { },
    }).then(res =>{
      if(!res){return}
      if(res.code == 200){
        res.data.map((item =>{
          item.dictValue = item.areaName
          item.code = item.areaCode
        }))
        this.setState({
          tagList: res.data
        })
      }
    })
  }

  // 单击 选择筛选条件
  onClick (data) {
    const { tagList } = this.state
    const { title } = this.props
    const findIndex = tagList.findIndex(item => item.dictValue == data.name)
    let selectedData = {
      sysType: "",
      // areaId:  "",
      // goPortId:  "",
      // cardId:  "",
      // serviceId: "",
    }
    //
    tagList.map((item, index) =>{
      if(index != findIndex){ // 可以取消选择 替代全部按钮
        item.active = false
      }
    })
    tagList[findIndex].active = !tagList[findIndex].active // 单击取反
    const isActive = tagList[findIndex].active
    setFilerProductParam(title.value, isActive?tagList[findIndex].code:"") // 更新过滤条件
    console.log(getGlobalData('filerProductParam'))
    this.setState({
      tagList: tagList,
    },()=>{
      this.getFilterList()  //获取过滤后的产品列表
    })
  }

  getFilterList =()=>{
    const { getProductList } = this.props
    getProductList && getProductList()
  }


  render () {
    const { title, style } = this.props
    return (
      <View className='conditions-container'>
        <View className='at-row'>
          <View className='at-col-2 t-center title'>{title.key}</View>
          <View className='at-col-10'>
            { this.state.tagList.map((item, index) => (
               <AtTag
                 className='btn'
                 customStyle={style}
                 key={index}
                 type='primary'
                 name={item.dictValue}
                 active={item.active}
                 onClick={this.onClick.bind(this)}
               >{item.dictValue}</AtTag>
              ))
            }
          </View>
        </View>
      </View>
    )
  }
}
