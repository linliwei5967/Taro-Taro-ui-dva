import React, { Component } from 'react'
import Taro from '@tarojs/taro'
import { View, Text, Image } from '@tarojs/components'
import './index.scss'
import {getGlobalData} from "../../../utils/global";
// import '../../../assets/icons/iconfont.css'

export default class ProductList extends Component {
  // constructor (props) {
  //   super(...props)
  //   this.state = {
  //     imgUrl: getGlobalData("imgUrl"), // 推荐列表
  //   }
  // }

  // componentDidMount () {
  //   // 获取推荐栏目列表
  //   // this.getRecommendList()
  // }
  //

  onGetDetail = (id, sysType) => {
    Taro.navigateTo({
      url: `/pages/product/index?bizId=${id}&sysType=${sysType}`
    })
  }

  render () {
    const { list } = this.props
    // const { imgUrl } = this.state
    return (
      <View className='home-recommend'>
        <View className='home-recommend__list'>
          {list.length>0 && list.map((item,index) => {
            { item = {
              ...item,
              agreementDefineName: item.agreementDefineName?item.agreementDefineName:"测试数据",
              comment: item.comment?item.comment:"测试数据",
            }}
            return (
              <View
                key={index}
                className='home-recommend__list-item'
                onClick={this.onGetDetail.bind(this, item.id, item.sysType)}
              >
                {/*<Image className='home-recommend__list-item-img' src={item.imgUrl} />*/}
                <Image className='home-recommend__list-item-img' src={item.img1?getGlobalData("imgUrl") + item.img1:""} />
                {/*<Text className={'home-recommend__list-item-img iconfont icon-yiliaohangyedeICON-'}/>*/}
                {!!item.comment &&
                  <Text className='home-recommend__list-item-desc' numberOfLines={1}>
                    {item.comment}
                  </Text>
                }
                <View className='home-recommend__list-item-info'>
                  <Text className='home-recommend__list-item-name' numberOfLines={1}>
                    {item.agreementDefineName}
                  </Text>
                  <View className='home-recommend__list-item-price-wrap'>
                    <Text className='home-recommend__list-item-price'>
                      ¥{item.price || 9999}
                    </Text>
                    {!!item.price &&
                      <Text className='home-recommend__list-item-price--origin'>
                        {/*¥{item.retailPrice}*/}
                        ¥{999}
                      </Text>
                    }
                  </View>
                </View>
              </View>
            )
          })}
        </View>
      </View>
    )
  }
}
