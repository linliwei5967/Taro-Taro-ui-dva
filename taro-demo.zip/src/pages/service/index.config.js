export default {
  navigationBarTitleText: '服务'
}
