import Taro, { getCurrentInstance } from '@tarojs/taro'
import React, { Component } from 'react'
import { View } from '@tarojs/components'
import { AtNoticebar } from 'taro-ui'
import './index.scss'

export default class NoticeBar extends Component {
  constructor(props) {
    super(props)
    this.state = {

    }
  }

  render () {
    return (
        <AtNoticebar marquee icon='volume-plus' speed={50} close>
          [消息通知] 12-14 鞍山市成达电气安装公司签订“协议客户协议”一份
        </AtNoticebar>
    )
  }
}
