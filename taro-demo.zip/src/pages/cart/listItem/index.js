import React, { Component } from 'react'
import Taro from '@tarojs/taro'
import { View, Text, Image } from '@tarojs/components'
import { CheckboxItem, InputNumber } from "../../../components";
import './index.scss'
import {connect} from "react-redux";

@connect(({ indexModel })=>{
  const { data } = indexModel
  return {
    indexModel,
  }
})
export default class ListItem extends Component {
  static defaultProps = {
    list: [],
    onUpdate: () => {},
    onUpdateCheck: () => {}
  }

  componentDidMount () {
    console.log(this.props)
  }

  getBaseItem = (item) => ({
    skuId: item.skuId,
    type: item.type,
    extId: item.extId,
    cnt: item.cnt,
    checked: item.checked,
    canCheck: true,
    promId: this.props.promId,
    promType: this.props.promType
  })

  handleUpdate = (item, cnt) => {
    const payload = {
      skuList: [{ ...this.getBaseItem(item), cnt }]
    }
    this.props.onUpdate(payload)
  }

  handleUpdateCheck = (item) => {
    const payload = {
      skuList: [{ ...this.getBaseItem(item), checked: !item.checked }]
    }
    this.props.onUpdateCheck(payload)
  }

  handleRemove = () => {
    // XXX 暂未实现左滑删除
  }

  render () {
    const { list } = this.props
    return (
      <View className='cart-list'>
        {/*{list.map(item => (*/}
          <View
            key={1}
            className='cart-list__item'
          >
            <CheckboxItem
              checked={true}
              onClick={this.handleUpdateCheck.bind(this)}
            />
            <Image
              className='cart-list__item-img'
              src={'http://192.168.0.12:80/cloud-system/data/getResource/1338325207466274818'}
            />
            <View className='cart-list__item-info'>
              <View className='cart-list__item-title'>
                {/*{!!item.prefix &&*/}
                  <Text className='cart-list__item-title-tag'>{"限时九折"}</Text>
                {/*}*/}
                <Text className='cart-list__item-title-name' numberOfLines={1}>
                  {'超级会员卡'}
                </Text>
              </View>

              <View className='cart-list__item-spec'>
                <Text className='cart-list__item-spec-txt'>
                  {/*{item.specList.map(sepc => sepc.specValue).join(' ')}*/}
                  过年收礼还收白金卡
                </Text>
              </View>

              <View className='cart-list__item-wrap'>
                <Text className='cart-list__item-price'>
                  ¥{666.98}
                </Text>
                <View className='cart-list__item-num'>
                  <InputNumber
                    num={1}
                    onChange={this.handleUpdate.bind(this)}
                  />
                </View>
              </View>
            </View>
          </View>
        {/*))}*/}
      </View>
    )
  }
}

