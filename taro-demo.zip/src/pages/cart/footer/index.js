import React, { Component } from 'react'
import Taro from '@tarojs/taro'
import { View, Text } from '@tarojs/components'
import './index.scss'
import { ButtonItem, CheckboxItem } from "../../../components";
import {getGlobalData} from "../../../utils/global";

export default class Footer extends Component {
  constructor (props) {
    super(props)
    this.state = {
      isAllCheck: false,
    }
  }

  handleUpdateCheck = () => {
    this.setState({
      isAllCheck: !this.state.isAllCheck
    })
  }

  handleOrder = () => {
    Taro.showToast({
      title: '敬请期待',
      icon: 'none'
    })
  }


  render () {
    const { cartInfo } = this.props
    const { isAllCheck } = this.state
    return (
      <View className='cart-footer'>
        <View className='cart-footer__select'>
          <CheckboxItem
            checked={isAllCheck}
            onClick={this.handleUpdateCheck}
          >
            <Text className='cart-footer__select-txt'>
              {!cartInfo.selectedCount ? '全选' : `已选(${cartInfo.selectedCount})`}
            </Text>
          </CheckboxItem>
        </View>
        <View className='cart-footer__amount'>
          <Text className='cart-footer__amount-txt'>
            ¥{parseFloat(669.86).toFixed(2)}
          </Text>
        </View>
        <View className='cart-footer__btn'>
          <ButtonItem
            type='primary'
            text='结算'
            onClick={this.handleOrder}
          />
        </View>
      </View>
    )
  }
}
