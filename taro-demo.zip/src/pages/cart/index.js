import React, { Component } from 'react'
import Taro from '@tarojs/taro'
import { View, Text, Image, ScrollView } from '@tarojs/components'
import Empty from './empty'
import Footer from './footer'
import ButtonItem from "../../components/button";
import ListItem from "./listItem/index";
import './index.scss'
import {getWindowHeight} from "../../utils/style";

export default class Cart extends Component {
  constructor(props) {
    super(props)
    this.state = {
      loaded: false,
      login: false
    }
  }

  componentDidShow() {

  }

  toLogin = () => {
    Taro.navigateTo({
      url: '/pages/login/index'
    })
  }

  render () {
    const { } = this.props

    // if(!Taro.getStorageSync('userId')){
    //   return (
    //     <View className='cart cart--not-login'>
    //       <Empty text='未登陆' />
    //       <View className='cart__login'>
    //         <ButtonItem
    //           type='primary'
    //           text='登录'
    //           onClick={this.toLogin}
    //           compStyle={{
    //             background: '#b59f7b',
    //             // background: '#458B74',
    //             borderRadius: Taro.pxTransform(4)
    //           }}
    //         />
    //       </View>
    //       <View className='cart__footer'>
    //         <Footer
    //           cartInfo={{}}
    //           onUpdateCheck={this.toLogin}
    //         />
    //       </View>
    //     </View>
    //   )
    // }

    if(true){
      return (
        <View className='cart'>
          <ScrollView
            scrollY
            className='cart__wrap'
            style={{ height: getWindowHeight() }}
          >
            <ListItem
              // key={`${group.promId}_${index}`}
              // promId={group.promId}
              // promType={group.promType}
              // list={group.cartItemList}
              // onUpdate={this.props.dispatchUpdate}
              // onUpdateCheck={this.props.dispatchUpdateCheck}
            />

            <View className='cart__footer'>
              <Footer
                cartInfo={{}}
                onUpdateCheck={this.toLogin}
              />
            </View>
          </ScrollView>
        </View>
      )
    }
  }
}
