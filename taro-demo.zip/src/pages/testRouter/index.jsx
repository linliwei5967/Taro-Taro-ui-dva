import React, { Component } from 'react'
import { View, Text } from '@tarojs/components'
import {AtButton, AtCalendar} from 'taro-ui'
import { getLatestTopic } from '../../utils/common'
import Taro from '@tarojs/taro'
import { AtAccordion, AtList, AtListItem } from 'taro-ui'
import "taro-ui/dist/style/components/calendar.scss";
import "taro-ui/dist/style/components/button.scss" // 按需引入
import './index.scss'
import "taro-ui/dist/style/components/accordion.scss";
import "taro-ui/dist/style/components/icon.scss";

export default class TestRouter extends Component {

  async componentWillMount () {
    try {
      const res = await Taro.request({
        url: getLatestTopic()
      })
      this.setState({
        threads: res.data,
        loading: false
      })
    } catch (error) {
      // Taro.showToast({
      //   title: '载入远程数据错误'
      // })
    }
  }

  constructor () {
    super(...arguments)
    this.state = {
      open: true,
    }
  }
  componentDidMount () { }

  componentWillUnmount () { }

  componentDidShow () { }

  componentDidHide () { }

  render () {
    return (
      <View className='index'>
        <AtCalendar />
        {/*<AtAccordion title='标题三' icon={{ value: 'chevron-down', color: 'red', size: '15' }}     open={this.state.open}>*/}
          {/*<AtList hasBorder={false}>*/}
            {/*<AtListItem*/}
              {/*title='标题文字'*/}
              {/*arrow='right'*/}
              {/*thumb='https://img12.360buyimg.com/jdphoto/s72x72_jfs/t6160/14/2008729947/2754/7d512a86/595c3aeeNa89ddf71.png'*/}
            {/*/>*/}
            {/*<AtListItem*/}
              {/*title='标题文字'*/}
              {/*note='描述信息'*/}
              {/*arrow='right'*/}
              {/*thumb='http://img10.360buyimg.com/jdphoto/s72x72_jfs/t5872/209/5240187906/2872/8fa98cd/595c3b2aN4155b931.png'*/}
            {/*/>*/}
            {/*<AtListItem*/}
              {/*title='标题文字'*/}
              {/*note='描述信息'*/}
              {/*extraText='详细信息'*/}
              {/*arrow='right'*/}
              {/*thumb='http://img12.360buyimg.com/jdphoto/s72x72_jfs/t10660/330/203667368/1672/801735d7/59c85643N31e68303.png'*/}
            {/*/>*/}
          {/*</AtList>*/}
        {/*</AtAccordion>*/}
        <AtButton type='primary' onClick={this.handleNavigate}>我是第二个页面</AtButton>
      </View>
    )
  }
}
