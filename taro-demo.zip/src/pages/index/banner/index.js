import Taro from '@tarojs/taro'
import React, { Component } from 'react'
import {Swiper, SwiperItem, Image,} from '@tarojs/components'
import { Request } from '../../../utils/request.js'
import './index.scss'
import bak1 from '../../../assets/images/banner/banner1.png'
import bak2 from '../../../assets/images/banner/banner2.png'
import bak3 from '../../../assets/images/banner/banner3.png'
import {connect} from "react-redux";
@connect(({ })=>{return {}})

// 首页轮播图
export default class Banner extends Component {
  constructor (props) {
    super(props)
    this.state = {
      current: 1,
      duration: 500,
      interval: 5000,
      isCircular: true,
      isAutoplay: true,
      hasIndicatorDots: true,
      bannerList: [{
        linkUrl: bak1
      },{
        linkUrl: bak2
      },{
        linkUrl: bak3
      },
      ], // 录播图数据
    }
  }

  componentDidMount () {
    // 获取轮播图列表
    this.getBannerList()
  }

  // 获取首页顶部轮播图列表
  getBannerList = () =>{
    const { dispatch, params } = this.props
    dispatch({
      type: 'indexModel/getRecommendList',
      payload: {bannerType: "HomeBanner",},
    }).then(res=>{
      if(res.code == "200"){
        this.setState({
          // bannerList: res.data,
        })
      }
    })
  }

  // handleNavigate = () => {
  //   Taro.navigateTo({
  //     url: '/pages/detail/index'
  //   })
  // }

  render () {
    const { current, isAutoplay, duration, isCircular, interval, hasIndicatorDots, bannerList } = this.state
    return (
        // 276 x 159
        <Swiper
          indicatorColor='#999'
          indicatorActiveColor='#333'
          current={current}
          duration={duration}
          interval={interval}
          circular={isCircular}
          autoplay={isAutoplay}
          indicatorDots={hasIndicatorDots}
          previousMargin='20'
        >
          {
            bannerList && bannerList.map((item, index) => (
              <SwiperItem key={index}>
                <Image src={item.linkUrl} className='slide-image' />
                {/*<Image src={bak} className='slide-image' />*/}
              </SwiperItem>
            ))
          }
        </Swiper>
    )
  }
}
