import React, { Component } from 'react'
import Taro from '@tarojs/taro'
import { View, Text, Image } from '@tarojs/components'
import { Request } from "../../../utils/request.js"
import {recommendList} from './data'
import './index.scss'
import {getGlobalData} from "../../../utils/global";
import '../../../assets/icons/iconfont.css'
import {connect} from "react-redux";

@connect(({ })=>{return {}})
export default class Recommend extends Component {
  constructor (props) {
    super(props)
    this.state = {
      recommendList: [], // 推荐列表
      imgUrl: getGlobalData("imgUrl"), // 推荐列表
    }
  }

  componentDidMount () {
    this.getRecommendList() // 获取推荐栏目列表
  }

  // 获取首页精选列表
  getRecommendList = () =>{
    const { dispatch, params } = this.props
    dispatch({
      type: 'indexModel/getRecommendList',
      payload: {...params},
    }).then(res=>{
      if(res.code == "200"){
        this.setState({
          recommendList: res.data,
        })
      }
    })
  }

  onGetDetail = (id, recommendType) => {
    Taro.navigateTo({
      url: `/pages/product/index?bizId=${id}&sysType=${recommendType}`
    })
  }

  render () {
    const { recommendList } = this.state
    const { imgUrl } = this.state
    return (
      <View className='home-recommend'>
        <View className='home-recommend__list'>
          {recommendList && recommendList.map((item,index) => {
            { item = {
              ...item,
              agreementDefineName: item.agreementDefineName?item.agreementDefineName:"测试数据",
              comment: item.comment?item.comment:"测试数据",
              // comment: item.comment?item.comment:"暂无",
            }}
            // item.imgUrl = 'https://yanxuan-item.nosdn.127.net/82de8fdea1c8bba21b26099612ff5605.png'
            return (
              <View
                key={index}
                className='home-recommend__list-item'
                onClick={this.onGetDetail.bind(this, item.id, item.recommendType)}
              >
                {/*<Image className='home-recommend__list-item-img' src={item.imgUrl} />*/}
                <Image className='home-recommend__list-item-img' src={item.img1?imgUrl + item.img1:""} />
                {/*<Text className={'home-recommend__list-item-img iconfont icon-yiliaohangyedeICON-'}/>*/}
                {!!item.comment &&
                  <Text className='home-recommend__list-item-desc' numberOfLines={1}>
                    {item.comment}
                  </Text>
                }
                <View className='home-recommend__list-item-info'>
                  <Text className='home-recommend__list-item-name' numberOfLines={1}>
                    {item.agreementDefineName}
                  </Text>
                  <View className='home-recommend__list-item-price-wrap'>
                    <Text className='home-recommend__list-item-price'>
                      ¥{item.price || 9999}
                    </Text>
                    {!!item.price &&
                      <Text className='home-recommend__list-item-price--origin'>
                        {/*¥{item.retailPrice}*/}
                        ¥{999}
                      </Text>
                    }
                  </View>
                </View>
              </View>
            )
          })}
        </View>
      </View>
    )
  }
}
