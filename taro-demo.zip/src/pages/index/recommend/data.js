

export const recommendList = [
  {
    "id": "001",
    "name": "严选礼品卡 999.99元面值",
    "simpleDesc": "高档、精致、省心的礼赠佳品",
    "activityPrice": 6899.68,
    "retailPrice": 99999.99,
    "imgUrl": "https://yanxuan-item.nosdn.127.net/55425f24345d01992d61a1646325ac94.png"
  },{
    "id": "002",
    "name": "个人白金卡",
    "simpleDesc": "限时特价 就这起",
    "activityPrice": 7899.68,
    "retailPrice": 61254.99,
    "imgUrl": "https://yanxuan-item.nosdn.127.net/82de8fdea1c8bba21b26099612ff5605.png"
  },{
    "id": "003",
    "name": "个人白银卡",
    "simpleDesc": "限时特价 就这起",
    "activityPrice": 1213.68,
    "retailPrice": 9687.99,
    "imgUrl": "https://yanxuan-item.nosdn.127.net/82de8fdea1c8bba21b26099612ff5605.png"
  },{
    "id": "004",
    "name": "全净皓齿变速声波电动牙刷",
    "simpleDesc": "限时特价 九折起",
    "activityPrice": 88512.68,
    "retailPrice": 96877.99,
    "imgUrl": "https://yanxuan-item.nosdn.127.net/950f49bd47c615e774fcfdae2fe9f3c0.png"
  },
]


  // [
  // {
  //   "type": 0,
  //   "indexRcmdPic": {
  //     "title": "茅台抢购",
  //     "desc": null,
  //     "picUrls": [
  //       "https://yanxuan.nosdn.127.net/66479ef79c80cecb70a8a0264509752c.png"
  //     ],
  //     "targetJump": "/pages/webview/index?url=https%3A%2F%2Fact.you.163.com%2Fact%2Fpub%2Fr9qU7aXysgfW.html",
  //     "payload": {
  //       "linkType": 1
  //     }
  //   },
  //   "categoryItem": null,
  //   "pinItem": null,
  //   "id": 0
  // },
  //   {
  //     "type": 1,
  //     "indexRcmdPic": null,
  //     "categoryItem": {
  //       "id": 3995885,
  //       "name": "飞天53度贵州茅台酒 500毫升",
  //       "categoryId": 109264007,
  //       "primaryPicUrl": "https://yanxuan-item.nosdn.127.net/c40842640f6a1a2509960c2029aca1b8.png",
  //       "listPicUrl": "https://yanxuan-item.nosdn.127.net/fd28bdf16a9b79d44a7ee82878c64574.png",
  //       "retailPrice": 1499,
  //       "activityPrice": null,
  //       "soldOut": false,
  //       "few": false,
  //       "last": false,
  //       "simpleDesc": "茅台飘香，正品溯源",
  //       "simpleDescClose": false,
  //       "extraPrice": "",
  //       "newOnShelf": false,
  //       "forSale": false,
  //       "specification": null,
  //       "unShelf": false,
  //       "limitedFlag": false,
  //       "limitedTag": "",
  //       "productPlace": "",
  //       "itemTagList": null,
  //       "goodRate": null,
  //       "heat": null,
  //       "repoCount": null,
  //       "scenePicUrl": "https://yanxuan-item.nosdn.127.net/81a2e383474f65af73defbca1c484ece.png",
  //       "freshman": false,
  //       "appExclusiveFlag": false,
  //       "accessTime": 0,
  //       "promotionFlag": 0,
  //       "specTag": null,
  //       "comments": [
  //         {
  //           "skuInfo": [
  //             "1瓶"
  //           ],
  //           "frontUserName": "I****o",
  //           "frontUserAvatar": "http://thirdqq.qlogo.cn/qqapp/101330628/EABFCEDD6EE6F9AFAD2C6341E9CA26C5/100",
  //           "content": "这东西能抢到一瓶差不多十年的会员费就值回来了吧，有些人就别计较邮费什么的了，直呼严选🐮🍺",
  //           "createTime": 1603847355145,
  //           "picList": [
  //             "https://yanxuan.nosdn.127.net/5cc770a0450dea35428ee391b41bdda5.jpg"
  //           ],
  //           "kfReplyTitle": null,
  //           "kfReplyContent": null,
  //           "memLevel": 5,
  //           "appendCommentVO": null,
  //           "star": 5
  //         }
  //       ],
  //       "promBanner": null,
  //       "promLogo": null,
  //       "promDesc": null,
  //       "couponTag": null,
  //       "couponPrice": null,
  //       "depositSwapped": false,
  //       "returnPrice": null,
  //       "limitedSingleProm": false
  //     },
  //     "pinItem": null,
  //     "id": 3995885
  //   },
  //   {
  //     "type": 1,
  //     "indexRcmdPic": null,
  //     "categoryItem": {
  //       "id": 1282032,
  //       "name": "严选礼品卡 1000元面值",
  //       "categoryId": 1025000,
  //       "primaryPicUrl": "https://yanxuan-item.nosdn.127.net/72eb76506fb94adce584c74b930a6a92.png",
  //       "listPicUrl": "https://yanxuan-item.nosdn.127.net/55425f24345d01992d61a1646325ac94.png",
  //       "retailPrice": 1000,
  //       "activityPrice": null,
  //       "soldOut": false,
  //       "few": false,
  //       "last": false,
  //       "simpleDesc": "高档、精致、省心的礼赠佳品",
  //       "simpleDescClose": false,
  //       "extraPrice": "",
  //       "newOnShelf": false,
  //       "forSale": false,
  //       "specification": null,
  //       "unShelf": false,
  //       "limitedFlag": false,
  //       "limitedTag": "",
  //       "productPlace": "",
  //       "itemTagList": [],
  //       "goodRate": null,
  //       "heat": null,
  //       "repoCount": null,
  //       "scenePicUrl": "https://yanxuan-item.nosdn.127.net/a4e7213c0d64564f65a999a7575764a4.jpg",
  //       "freshman": false,
  //       "appExclusiveFlag": false,
  //       "accessTime": 0,
  //       "promotionFlag": 0,
  //       "specTag": null,
  //       "comments": [
  //         {
  //           "skuInfo": [
  //             "电子卡"
  //           ],
  //           "frontUserName": "用****1",
  //           "frontUserAvatar": null,
  //           "content": "在网易严选上购物是非常不错的选择",
  //           "createTime": 1606723669831,
  //           "picList": [
  //             "https://yanxuan.nosdn.127.net/00b6f3266af4cb7e663bf68063725c2c.jpg",
  //             "https://yanxuan.nosdn.127.net/b5b53382c0159c7af6c8d429326eaa0d.jpg",
  //             "https://yanxuan.nosdn.127.net/dc7fe886f6994c217cfdb849892f7c7e.jpg"
  //           ],
  //           "kfReplyTitle": null,
  //           "kfReplyContent": null,
  //           "memLevel": 1,
  //           "appendCommentVO": null,
  //           "star": 5
  //         }
  //       ],
  //       "promBanner": {
  //         "valid": false,
  //         "bannerType": 0,
  //         "promoTitle": null,
  //         "promoSubTitle": null,
  //         "content": null,
  //         "bannerTitleUrl": "https://yanxuan.nosdn.127.net/d71e2460d062eaa21d5bdf97eba9da89.png",
  //         "bannerContentUrl": "https://yanxuan.nosdn.127.net/c168892ef76f29971032dc1c12613720.png",
  //         "styleType": 1,
  //         "timeType": 0,
  //         "iconUrl": null,
  //         "usualContent": [],
  //         "firstOrderType": 0,
  //         "firstOrderTitle": null
  //       },
  //       "promLogo": null,
  //       "promDesc": null,
  //       "couponTag": null,
  //       "couponPrice": null,
  //       "depositSwapped": false,
  //       "returnPrice": null,
  //       "limitedSingleProm": false
  //     },
  //     "pinItem": null,
  //     "id": 1282032
  //   },
  //   {
  //     "type": 2,
  //     "indexRcmdPic": null,
  //     "categoryItem": null,
  //     "pinItem": {
  //       "id": 2041154,
  //       "description": "颗颗充氮锁鲜，传统九制芝麻丸",
  //       "categoryId": 1005002,
  //       "userNum": 2,
  //       "recentUsers": "[\"https://yanxuan.nosdn.127.net/662c1d899e55a7d01523be1629625354.jpg\",\"https://yanxuan.nosdn.127.net/c3a03895c73694d922310c76e4915cdb.png\",\"https://yanxuan.nosdn.127.net/c3a03895c73694d922310c76e4915cdb.png\"]",
  //       "picUrl": "https://yanxuan-item.nosdn.127.net/39b709912cd4d94617f9b8e27da12997.jpg",
  //       "title": "守护你的发际线，黑芝麻丸 100克",
  //       "itemId": 3990716,
  //       "price": 58,
  //       "originPrice": 99,
  //       "returnPrice": 0,
  //       "skuNum": 1,
  //       "joinUsers": 6778,
  //       "limitTime": false,
  //       "modeType": 2,
  //       "status": 0,
  //       "comments": [
  //         {
  //           "skuInfo": [
  //             "100克*3"
  //           ],
  //           "frontUserName": "勇*****",
  //           "frontUserAvatar": "https://yanxuan.nosdn.127.net/85a4a4ce686b0260f37626e26c314c25",
  //           "content": "铁罐装，每粒丸子都独立充氮包装。",
  //           "createTime": 1596953944291,
  //           "picList": [
  //             "https://yanxuan.nosdn.127.net/5f759f7fce41a700934e5a44a635f7fe.jpg",
  //             "https://yanxuan.nosdn.127.net/26213a90c0e5e105016ee34aedd1d6d2.jpg"
  //           ],
  //           "kfReplyTitle": null,
  //           "kfReplyContent": null,
  //           "memLevel": 4,
  //           "appendCommentVO": null,
  //           "star": 5
  //         }
  //       ]
  //     },
  //     "id": 3990716
  //   },
  //   {
  //     "type": 1,
  //     "indexRcmdPic": null,
  //     "categoryItem": {
  //       "id": 1076018,
  //       "name": "严选礼品卡 500元面值",
  //       "categoryId": 1025000,
  //       "primaryPicUrl": "https://yanxuan-item.nosdn.127.net/82de8fdea1c8bba21b26099612ff5605.png",
  //       "listPicUrl": "https://yanxuan-item.nosdn.127.net/82de8fdea1c8bba21b26099612ff5605.png",
  //       "retailPrice": 500,
  //       "activityPrice": null,
  //       "soldOut": false,
  //       "few": false,
  //       "last": false,
  //       "simpleDesc": "高档、精致、省心的礼赠佳品",
  //       "simpleDescClose": false,
  //       "extraPrice": "",
  //       "newOnShelf": false,
  //       "forSale": false,
  //       "specification": null,
  //       "unShelf": false,
  //       "limitedFlag": false,
  //       "limitedTag": "",
  //       "productPlace": "",
  //       "itemTagList": [],
  //       "goodRate": null,
  //       "heat": null,
  //       "repoCount": null,
  //       "scenePicUrl": "https://yanxuan-item.nosdn.127.net/bb40ae2c581cffd50118f0ff4419acf7.jpg",
  //       "freshman": false,
  //       "appExclusiveFlag": false,
  //       "accessTime": 0,
  //       "promotionFlag": 0,
  //       "specTag": null,
  //       "comments": [
  //         {
  //           "skuInfo": [
  //             "电子卡"
  //           ],
  //           "frontUserName": "M****弟",
  //           "frontUserAvatar": "https://yanxuan.nosdn.127.net/3daee9dc89993d0c19621daff7f64332",
  //           "content": "这个积分可以，直接可以抢购",
  //           "createTime": 1605146213907,
  //           "picList": [
  //             "https://yanxuan.nosdn.127.net/ed00b403e34f267a02196665bdb196a4.png",
  //             "https://yanxuan.nosdn.127.net/ea6c4cfed64c82ffc099c0f9ad1c76c8.png",
  //             "https://yanxuan.nosdn.127.net/8d215bd87b18336a81237607a74c1cf9.png"
  //           ],
  //           "kfReplyTitle": null,
  //           "kfReplyContent": null,
  //           "memLevel": 3,
  //           "appendCommentVO": null,
  //           "star": 5
  //         }
  //       ],
  //       "promBanner": {
  //         "valid": false,
  //         "bannerType": 0,
  //         "promoTitle": null,
  //         "promoSubTitle": null,
  //         "content": null,
  //         "bannerTitleUrl": "https://yanxuan.nosdn.127.net/d71e2460d062eaa21d5bdf97eba9da89.png",
  //         "bannerContentUrl": "https://yanxuan.nosdn.127.net/c168892ef76f29971032dc1c12613720.png",
  //         "styleType": 1,
  //         "timeType": 0,
  //         "iconUrl": null,
  //         "usualContent": [],
  //         "firstOrderType": 0,
  //         "firstOrderTitle": null
  //       },
  //       "promLogo": null,
  //       "promDesc": null,
  //       "couponTag": null,
  //       "couponPrice": null,
  //       "depositSwapped": false,
  //       "returnPrice": null,
  //       "limitedSingleProm": false
  //     },
  //     "pinItem": null,
  //     "id": 1076018
  //   },
  //   {
  //     "type": 1,
  //     "indexRcmdPic": null,
  //     "categoryItem": {
  //       "id": 3992120,
  //       "name": "男式咖啡碳保暖内衣2.0",
  //       "categoryId": 1093013,
  //       "primaryPicUrl": "https://yanxuan-item.nosdn.127.net/268ab6fc96bb61800aae957e60eadb40.png",
  //       "listPicUrl": "https://yanxuan-item.nosdn.127.net/f40f6154701343f401c0c249e60995d1.png",
  //       "retailPrice": 169,
  //       "activityPrice": "89.9",
  //       "soldOut": false,
  //       "few": false,
  //       "last": false,
  //       "simpleDesc": "专利咖啡碳面料",
  //       "simpleDescClose": false,
  //       "extraPrice": "",
  //       "newOnShelf": false,
  //       "forSale": false,
  //       "specification": null,
  //       "unShelf": false,
  //       "limitedFlag": true,
  //       "limitedTag": "新人特价包邮",
  //       "productPlace": "",
  //       "itemTagList": [
  //         {
  //           "type": 0,
  //           "name": "12.12爆单王",
  //           "itemTag": null,
  //           "itemTagType": null,
  //           "freshmanExclusive": false
  //         },
  //         {
  //           "type": 107,
  //           "name": "新人特价包邮",
  //           "itemTag": "XIAN_SHI_LIST",
  //           "itemTagType": null,
  //           "freshmanExclusive": false
  //         }
  //       ],
  //       "goodRate": null,
  //       "heat": null,
  //       "repoCount": null,
  //       "scenePicUrl": "https://yanxuan-item.nosdn.127.net/fcd2803cb855bdb979b33fb015151cd6.png",
  //       "freshman": false,
  //       "appExclusiveFlag": false,
  //       "accessTime": 0,
  //       "promotionFlag": 0,
  //       "specTag": "限时购",
  //       "comments": [
  //         {
  //           "skuInfo": [
  //             "黑色圆领",
  //             "XXL",
  //             "套装"
  //           ],
  //           "frontUserName": "冰****冰",
  //           "frontUserAvatar": "https://yanxuan.nosdn.127.net/774a7515f4a2c16fe1f60cf0f26f8b0f",
  //           "content": "轻薄!柔软! 舒适! 非常喜欢!   非常满意! 非常值得推荐的保暖内衣!  里面，毛茸茸! 暖和!",
  //           "createTime": 1602559563448,
  //           "picList": [
  //             "https://yanxuan.nosdn.127.net/fa2a73b2d2a0546bb6c6bd73c7aa5620.jpg"
  //           ],
  //           "kfReplyTitle": null,
  //           "kfReplyContent": null,
  //           "memLevel": 2,
  //           "appendCommentVO": null,
  //           "star": 5
  //         }
  //       ],
  //       "promBanner": {
  //         "valid": true,
  //         "bannerType": 0,
  //         "promoTitle": "新人特价包邮",
  //         "promoSubTitle": "¥89.9起",
  //         "content": "正在抢购中",
  //         "bannerTitleUrl": "https://yanxuan.nosdn.127.net/d71e2460d062eaa21d5bdf97eba9da89.png",
  //         "bannerContentUrl": "https://yanxuan.nosdn.127.net/c168892ef76f29971032dc1c12613720.png",
  //         "styleType": 1,
  //         "timeType": 0,
  //         "iconUrl": null,
  //         "usualContent": [],
  //         "firstOrderType": 0,
  //         "firstOrderTitle": null
  //       },
  //       "promLogo": {
  //         "logoUrl": "https://yanxuan.nosdn.127.net/58d6fda500049ef9f3f0301ecf6e2229.png",
  //         "width": 108,
  //         "height": 108
  //       },
  //       "promDesc": null,
  //       "couponTag": null,
  //       "couponPrice": null,
  //       "depositSwapped": false,
  //       "returnPrice": null,
  //       "limitedSingleProm": true
  //     },
  //     "pinItem": null,
  //     "id": 3992120
  //   },
  //   {
  //     "type": 2,
  //     "indexRcmdPic": null,
  //     "categoryItem": null,
  //     "pinItem": {
  //       "id": 2041155,
  //       "description": "8款健康食材精制，酸甜好味胃口大开",
  //       "categoryId": 1005002,
  //       "userNum": 2,
  //       "recentUsers": "[\"https://yanxuan.nosdn.127.net/c3a03895c73694d922310c76e4915cdb.png\",\"https://yanxuan.nosdn.127.net/c3a03895c73694d922310c76e4915cdb.png\",\"https://yanxuan.nosdn.127.net/c0f7357452827342ca0df708873719da.jpg\"]",
  //       "picUrl": "https://yanxuan-item.nosdn.127.net/774a5a2daf1deafea2540c0de1b06fc6.png",
  //       "title": "健康肠胃小助理，藜麦山楂丸 100克",
  //       "itemId": 3992892,
  //       "price": 58,
  //       "originPrice": 99,
  //       "returnPrice": 0,
  //       "skuNum": 1,
  //       "joinUsers": 2807,
  //       "limitTime": false,
  //       "modeType": 2,
  //       "status": 0,
  //       "comments": [
  //         {
  //           "skuInfo": [
  //             "100克/罐"
  //           ],
  //           "frontUserName": "儒*****",
  //           "frontUserAvatar": "https://yanxuan.nosdn.127.net/c7e16b64863fec89f5bf86af8a34ca7d.jpg",
  //           "content": "喜欢吃山楂的我看到上新，第一时间入手一盒，打开快递第一眼出乎预料，不愧是严选大品牌，小红盒很精致，还是继续贯彻严选携带方便的独立小包装，再看配料表没有任何化学品防腐剂添加，品尝第一口，嚼在嘴里软软的，酸酸甜甜略带一点橘皮的小清香，对于经常点外卖肠胃不太好的我，饭后必备一颗。",
  //           "createTime": 1600515847546,
  //           "picList": [
  //             "https://yanxuan.nosdn.127.net/05eb84cb576b92c257147ab52d99649b.jpg",
  //             "https://yanxuan.nosdn.127.net/1413ce541072510cbbbf0ea29c454d63.jpg",
  //             "https://yanxuan.nosdn.127.net/f3cb982a4dbf179a96cba03780e29054.jpg",
  //             "https://yanxuan.nosdn.127.net/b8c487c84040eff3c39fcfec82b84700.jpg",
  //             "https://yanxuan.nosdn.127.net/2e8560b7ddcdd062e6e6a90ce23639d7.jpg"
  //           ],
  //           "kfReplyTitle": null,
  //           "kfReplyContent": null,
  //           "memLevel": 3,
  //           "appendCommentVO": null,
  //           "star": 5
  //         }
  //       ]
  //     },
  //     "id": 3992892
  //   },
  //   {
  //     "type": 1,
  //     "indexRcmdPic": null,
  //     "categoryItem": {
  //       "id": 3992121,
  //       "name": "女式咖啡碳保暖内衣2.0",
  //       "categoryId": 109272000,
  //       "primaryPicUrl": "https://yanxuan-item.nosdn.127.net/50987f5b3a71dcd93372557250cbba06.png",
  //       "listPicUrl": "https://yanxuan-item.nosdn.127.net/6c919dc19e1081c3b2d8ca5fe1d7860e.png",
  //       "retailPrice": 169,
  //       "activityPrice": "79",
  //       "soldOut": false,
  //       "few": false,
  //       "last": false,
  //       "simpleDesc": "专利咖啡碳面料",
  //       "simpleDescClose": false,
  //       "extraPrice": "",
  //       "newOnShelf": false,
  //       "forSale": false,
  //       "specification": null,
  //       "unShelf": false,
  //       "limitedFlag": true,
  //       "limitedTag": "新人特价包邮",
  //       "productPlace": "",
  //       "itemTagList": [
  //         {
  //           "type": 0,
  //           "name": "12.12爆单王",
  //           "itemTag": null,
  //           "itemTagType": null,
  //           "freshmanExclusive": false
  //         },
  //         {
  //           "type": 107,
  //           "name": "新人特价包邮",
  //           "itemTag": "XIAN_SHI_LIST",
  //           "itemTagType": null,
  //           "freshmanExclusive": false
  //         }
  //       ],
  //       "goodRate": null,
  //       "heat": null,
  //       "repoCount": null,
  //       "scenePicUrl": "https://yanxuan-item.nosdn.127.net/ed5a4852d2de764417272990fae7e5db.png",
  //       "freshman": false,
  //       "appExclusiveFlag": false,
  //       "accessTime": 0,
  //       "promotionFlag": 0,
  //       "specTag": "限时购",
  //       "comments": [
  //         {
  //           "skuInfo": [
  //             "蓝色",
  //             "圆领",
  //             "M",
  //             "套装"
  //           ],
  //           "frontUserName": "1****3",
  //           "frontUserAvatar": "https://yanxuan.nosdn.127.net/7540beae4d2280e49ba42c176cfd5ec3.jpg",
  //           "content": "一如既往的好，以前买过类似的",
  //           "createTime": 1602237842259,
  //           "picList": [
  //             "https://yanxuan.nosdn.127.net/dbce82f4d1bebf2d207c6d7a83c3f882.jpg"
  //           ],
  //           "kfReplyTitle": null,
  //           "kfReplyContent": null,
  //           "memLevel": 6,
  //           "appendCommentVO": null,
  //           "star": 5
  //         }
  //       ],
  //       "promBanner": {
  //         "valid": true,
  //         "bannerType": 0,
  //         "promoTitle": "新人特价包邮",
  //         "promoSubTitle": "¥79起",
  //         "content": "正在抢购中",
  //         "bannerTitleUrl": "https://yanxuan.nosdn.127.net/d71e2460d062eaa21d5bdf97eba9da89.png",
  //         "bannerContentUrl": "https://yanxuan.nosdn.127.net/c168892ef76f29971032dc1c12613720.png",
  //         "styleType": 1,
  //         "timeType": 0,
  //         "iconUrl": null,
  //         "usualContent": [],
  //         "firstOrderType": 0,
  //         "firstOrderTitle": null
  //       },
  //       "promLogo": {
  //         "logoUrl": "https://yanxuan.nosdn.127.net/58d6fda500049ef9f3f0301ecf6e2229.png",
  //         "width": 108,
  //         "height": 108
  //       },
  //       "promDesc": null,
  //       "couponTag": null,
  //       "couponPrice": null,
  //       "depositSwapped": false,
  //       "returnPrice": null,
  //       "limitedSingleProm": true
  //     },
  //     "pinItem": null,
  //     "id": 3992121
  //   },
  //   {
  //     "type": 1,
  //     "indexRcmdPic": null,
  //     "categoryItem": {
  //       "id": 1154003,
  //       "name": "全净皓齿变速声波电动牙刷",
  //       "categoryId": 1037003,
  //       "primaryPicUrl": "https://yanxuan-item.nosdn.127.net/7a0e064c1fd99b5eb16608bca9b7aa0d.png",
  //       "listPicUrl": "https://yanxuan-item.nosdn.127.net/950f49bd47c615e774fcfdae2fe9f3c0.png",
  //       "retailPrice": 49,
  //       "activityPrice": null,
  //       "soldOut": false,
  //       "few": false,
  //       "last": false,
  //       "simpleDesc": "30万+好评爆款，洁齿护龈两不误",
  //       "simpleDescClose": false,
  //       "extraPrice": "",
  //       "newOnShelf": false,
  //       "forSale": false,
  //       "specification": null,
  //       "unShelf": false,
  //       "limitedFlag": false,
  //       "limitedTag": "年终底价",
  //       "productPlace": "",
  //       "itemTagList": [],
  //       "goodRate": null,
  //       "heat": null,
  //       "repoCount": null,
  //       "scenePicUrl": "https://yanxuan-item.nosdn.127.net/470c4cc3c68b48bb5f486e31beeb8978.jpg",
  //       "freshman": false,
  //       "appExclusiveFlag": false,
  //       "accessTime": 0,
  //       "promotionFlag": 0,
  //       "specTag": "限时购",
  //       "comments": [
  //         {
  //           "skuInfo": [
  //             "粉色"
  //           ],
  //           "frontUserName": "1****2",
  //           "frontUserAvatar": null,
  //           "content": "特别好",
  //           "createTime": 1599320144384,
  //           "picList": [
  //             "https://yanxuan.nosdn.127.net/a9f4561e619bdc3326d5229ae3a04c26.jpg"
  //           ],
  //           "kfReplyTitle": null,
  //           "kfReplyContent": null,
  //           "memLevel": 3,
  //           "appendCommentVO": null,
  //           "star": 5
  //         }
  //       ],
  //       "promBanner": {
  //         "valid": true,
  //         "bannerType": 0,
  //         "promoTitle": "0元",
  //         "promoSubTitle": null,
  //         "content": "首单全额返 下单立返49元",
  //         "bannerTitleUrl": "https://yanxuan.nosdn.127.net/d71e2460d062eaa21d5bdf97eba9da89.png",
  //         "bannerContentUrl": "https://yanxuan.nosdn.127.net/c168892ef76f29971032dc1c12613720.png",
  //         "styleType": 0,
  //         "timeType": 0,
  //         "iconUrl": null,
  //         "usualContent": [],
  //         "firstOrderType": 1,
  //         "firstOrderTitle": "0"
  //       },
  //       "promLogo": null,
  //       "promDesc": null,
  //       "couponTag": null,
  //       "couponPrice": null,
  //       "depositSwapped": false,
  //       "returnPrice": null,
  //       "limitedSingleProm": false
  //     },
  //     "pinItem": null,
  //     "id": 1154003
  //   },
  //   {
  //     "type": 2,
  //     "indexRcmdPic": null,
  //     "categoryItem": null,
  //     "pinItem": {
  //       "id": 2041156,
  //       "description": "轻轻松松赶走“湿”态",
  //       "categoryId": 1005002,
  //       "userNum": 2,
  //       "recentUsers": "[\"https://yanxuan.nosdn.127.net/c3a03895c73694d922310c76e4915cdb.png\",\"https://yanxuan.nosdn.127.net/c3a03895c73694d922310c76e4915cdb.png\",\"https://yanxuan.nosdn.127.net/4955acec7ad93a919d4f2beefdea49e7\"]",
  //       "picUrl": "https://yanxuan-item.nosdn.127.net/dc2155452a8f560cf1bd49bc26c82683.jpg",
  //       "title": "红豆薏米丸",
  //       "itemId": 3805088,
  //       "price": 58,
  //       "originPrice": 99,
  //       "returnPrice": 0,
  //       "skuNum": 1,
  //       "joinUsers": 2958,
  //       "limitTime": false,
  //       "modeType": 2,
  //       "status": 0,
  //       "comments": [
  //         {
  //           "skuInfo": [
  //             "100克"
  //           ],
  //           "frontUserName": "E****I",
  //           "frontUserAvatar": "https://yanxuan.nosdn.127.net/67736b279a2a8e23a55d6060210080ac.jpg",
  //           "content": "本来是买来口服除湿！！没想到还挺好吃的⊙▽⊙一打开香气扑鼻🙊越嚼越香",
  //           "createTime": 1582351939402,
  //           "picList": [
  //             "https://yanxuan.nosdn.127.net/f75bf9b0baa09ce465486c25918aad7f.jpg",
  //             "https://yanxuan.nosdn.127.net/690aeea99557fbc4566dae2f2baee2a3.jpg"
  //           ],
  //           "kfReplyTitle": null,
  //           "kfReplyContent": null,
  //           "memLevel": 5,
  //           "appendCommentVO": null,
  //           "star": 5
  //         }
  //       ]
  //     },
  //     "id": 3805088
  //   },
  //   {
  //     "type": 1,
  //     "indexRcmdPic": null,
  //     "categoryItem": {
  //       "id": 3468034,
  //       "name": "肉香满满，火腿猪肉罐头 198克",
  //       "categoryId": 109201001,
  //       "primaryPicUrl": "https://yanxuan-item.nosdn.127.net/738419f0f36699626fa5d74914b6dfba.png",
  //       "listPicUrl": "https://yanxuan-item.nosdn.127.net/738419f0f36699626fa5d74914b6dfba.png",
  //       "retailPrice": 22,
  //       "activityPrice": "19.9",
  //       "soldOut": false,
  //       "few": false,
  //       "last": false,
  //       "simpleDesc": "≥90%含肉量，肉粒鲜嫩可见",
  //       "simpleDescClose": false,
  //       "extraPrice": "",
  //       "newOnShelf": false,
  //       "forSale": false,
  //       "specification": null,
  //       "unShelf": false,
  //       "limitedFlag": true,
  //       "limitedTag": "年终底价",
  //       "productPlace": "",
  //       "itemTagList": [
  //         {
  //           "type": 0,
  //           "name": "22万+人已加购",
  //           "itemTag": null,
  //           "itemTagType": null,
  //           "freshmanExclusive": false
  //         },
  //         {
  //           "type": 107,
  //           "name": "年终底价",
  //           "itemTag": "XIAN_SHI_LIST",
  //           "itemTagType": null,
  //           "freshmanExclusive": false
  //         },
  //         {
  //           "type": 5,
  //           "name": "每满200减25券",
  //           "itemTag": null,
  //           "itemTagType": null,
  //           "freshmanExclusive": false
  //         }
  //       ],
  //       "goodRate": null,
  //       "heat": null,
  //       "repoCount": null,
  //       "scenePicUrl": "https://yanxuan-item.nosdn.127.net/72172b06914ab06f531329466f71b835.png",
  //       "freshman": false,
  //       "appExclusiveFlag": false,
  //       "accessTime": 0,
  //       "promotionFlag": 0,
  //       "specTag": "限时购",
  //       "comments": [
  //         {
  //           "skuInfo": [
  //             "198克"
  //           ],
  //           "frontUserName": "用****3",
  //           "frontUserAvatar": null,
  //           "content": "2天干掉1⃣️罐，立马追加2⃣️罐👍🏻",
  //           "createTime": 1603119398794,
  //           "picList": [
  //             "https://yanxuan.nosdn.127.net/4432dbc74808888ecc99602013d3705f.jpg",
  //             "https://yanxuan.nosdn.127.net/eb69e6d022698b8c69a702591e204892.jpg"
  //           ],
  //           "kfReplyTitle": null,
  //           "kfReplyContent": null,
  //           "memLevel": 2,
  //           "appendCommentVO": null,
  //           "star": 5
  //         }
  //       ],
  //       "promBanner": {
  //         "valid": true,
  //         "bannerType": 0,
  //         "promoTitle": "年终底价",
  //         "promoSubTitle": "¥19.9起",
  //         "content": "限3000件 仅剩1天",
  //         "bannerTitleUrl": "https://yanxuan.nosdn.127.net/d71e2460d062eaa21d5bdf97eba9da89.png",
  //         "bannerContentUrl": "https://yanxuan.nosdn.127.net/c168892ef76f29971032dc1c12613720.png",
  //         "styleType": 1,
  //         "timeType": 0,
  //         "iconUrl": null,
  //         "usualContent": [],
  //         "firstOrderType": 0,
  //         "firstOrderTitle": null
  //       },
  //       "promLogo": {
  //         "logoUrl": "https://yanxuan.nosdn.127.net/58d6fda500049ef9f3f0301ecf6e2229.png",
  //         "width": 108,
  //         "height": 108
  //       },
  //       "promDesc": null,
  //       "couponTag": null,
  //       "couponPrice": 17.41,
  //       "depositSwapped": false,
  //       "returnPrice": null,
  //       "limitedSingleProm": true
  //     },
  //     "pinItem": null,
  //     "id": 3468034
  //   },
  //   {
  //     "type": 1,
  //     "indexRcmdPic": null,
  //     "categoryItem": {
  //       "id": 1318002,
  //       "name": "每一口都有七种肉，全价猫粮 1.8千克",
  //       "categoryId": 1017000,
  //       "primaryPicUrl": "https://yanxuan-item.nosdn.127.net/feefe540760f3f43cc3d1a7e65f846d9.png",
  //       "listPicUrl": "https://yanxuan-item.nosdn.127.net/feefe540760f3f43cc3d1a7e65f846d9.png",
  //       "retailPrice": 88,
  //       "activityPrice": null,
  //       "soldOut": false,
  //       "few": false,
  //       "last": false,
  //       "simpleDesc": "多肉零谷物，升级低便臭配方",
  //       "simpleDescClose": false,
  //       "extraPrice": "",
  //       "newOnShelf": false,
  //       "forSale": false,
  //       "specification": null,
  //       "unShelf": false,
  //       "limitedFlag": false,
  //       "limitedTag": "年终底价",
  //       "productPlace": "",
  //       "itemTagList": [],
  //       "goodRate": null,
  //       "heat": null,
  //       "repoCount": null,
  //       "scenePicUrl": "https://yanxuan-item.nosdn.127.net/753a65fa300eec25311a2321b6ab80ad.jpg",
  //       "freshman": false,
  //       "appExclusiveFlag": false,
  //       "accessTime": 0,
  //       "promotionFlag": 0,
  //       "specTag": "限时购",
  //       "comments": [
  //         {
  //           "skuInfo": [
  //             "2.0配方 1.8千克*4袋"
  //           ],
  //           "frontUserName": "1****2",
  //           "frontUserAvatar": "https://yanxuan.nosdn.127.net/100b1e454e2b9ef23f8b435820b05372.jpg",
  //           "content": "这款喵粮非常好，猫咪喜欢吃。已经回购了好多次了，一直没有换过，以后也不会换！这次一下子买了四袋！",
  //           "createTime": 1602685099283,
  //           "picList": [
  //             "https://yanxuan.nosdn.127.net/5d1f57da4c5d6e98aff2ffdae74c4720.jpg",
  //             "https://yanxuan.nosdn.127.net/cd94f82f1a6a8252a37a5666a6b5a5c3.jpg"
  //           ],
  //           "kfReplyTitle": null,
  //           "kfReplyContent": null,
  //           "memLevel": 2,
  //           "appendCommentVO": null,
  //           "star": 5
  //         }
  //       ],
  //       "promBanner": {
  //         "valid": true,
  //         "bannerType": 0,
  //         "promoTitle": "0元",
  //         "promoSubTitle": null,
  //         "content": "首单全额返 下单立返88元",
  //         "bannerTitleUrl": "https://yanxuan.nosdn.127.net/d71e2460d062eaa21d5bdf97eba9da89.png",
  //         "bannerContentUrl": "https://yanxuan.nosdn.127.net/c168892ef76f29971032dc1c12613720.png",
  //         "styleType": 0,
  //         "timeType": 0,
  //         "iconUrl": null,
  //         "usualContent": [],
  //         "firstOrderType": 1,
  //         "firstOrderTitle": "0"
  //       },
  //       "promLogo": null,
  //       "promDesc": null,
  //       "couponTag": null,
  //       "couponPrice": null,
  //       "depositSwapped": false,
  //       "returnPrice": null,
  //       "limitedSingleProm": false
  //     },
  //     "pinItem": null,
  //     "id": 1318002
  //   },
  //   {
  //     "type": 2,
  //     "indexRcmdPic": null,
  //     "categoryItem": null,
  //     "pinItem": {
  //       "id": 2041157,
  //       "description": "萌趣可爱 还你一颗少女心",
  //       "categoryId": 109268000,
  //       "userNum": 2,
  //       "recentUsers": "[\"https://yanxuan.nosdn.127.net/e2f8783d04b53bc2af899851f33505c5\",\"https://yanxuan.nosdn.127.net/c291f819920a54d95abcf6bf7b9950f9\"]",
  //       "picUrl": "https://yanxuan-item.nosdn.127.net/1b124f0a60937f69c371cccca7534094.jpg",
  //       "title": "迪士尼米妮抱枕",
  //       "itemId": 3990127,
  //       "price": 58,
  //       "originPrice": 79,
  //       "returnPrice": 0,
  //       "skuNum": 1,
  //       "joinUsers": 2774,
  //       "limitTime": false,
  //       "modeType": 2,
  //       "status": 0,
  //       "comments": [
  //         {
  //           "skuInfo": [
  //             "米妮"
  //           ],
  //           "frontUserName": "m****8",
  //           "frontUserAvatar": "https://yanxuan.nosdn.127.net/e02f3e2ced7dd77f327d7d148fffdc8e.jpg",
  //           "content": "这款迪士尼米妮抱枕、做工精细、款式新颖、颜色很好看、唯一就是太小了、给小孩子们用还可以,的确太袖珍了、因为喜欢就留下来、再有大一号、颜色多样化就更完美了！",
  //           "createTime": 1605003817674,
  //           "picList": [
  //             "https://yanxuan.nosdn.127.net/1c5c4eb794ec083f83dd958b47986ccb.jpg",
  //             "https://yanxuan.nosdn.127.net/3a69449b32d7533f4ee2da9c8a5fff59.jpg"
  //           ],
  //           "kfReplyTitle": null,
  //           "kfReplyContent": null,
  //           "memLevel": 5,
  //           "appendCommentVO": null,
  //           "star": 5
  //         }
  //       ]
  //     },
  //     "id": 3990127
  //   },
  //   {
  //     "type": 1,
  //     "indexRcmdPic": null,
  //     "categoryItem": {
  //       "id": 3992464,
  //       "name": "男女后包两穿基础拖鞋",
  //       "categoryId": 1008010,
  //       "primaryPicUrl": "https://yanxuan-item.nosdn.127.net/22310922e55246eda0b1c032a4bf1179.png",
  //       "listPicUrl": "https://yanxuan-item.nosdn.127.net/d71da071b0d275c0a99ab6359416edb7.png",
  //       "retailPrice": 49,
  //       "activityPrice": null,
  //       "soldOut": false,
  //       "few": false,
  //       "last": false,
  //       "simpleDesc": "后包两穿，季度保暖",
  //       "simpleDescClose": false,
  //       "extraPrice": "",
  //       "newOnShelf": false,
  //       "forSale": false,
  //       "specification": "4色可选",
  //       "unShelf": false,
  //       "limitedFlag": false,
  //       "limitedTag": "",
  //       "productPlace": "",
  //       "itemTagList": [
  //         {
  //           "type": 0,
  //           "name": "17万+人已加购",
  //           "itemTag": null,
  //           "itemTagType": null,
  //           "freshmanExclusive": false
  //         },
  //         {
  //           "type": 103,
  //           "name": "2件8.5折",
  //           "itemTag": "MULTI__LIST",
  //           "itemTagType": null,
  //           "freshmanExclusive": false
  //         },
  //         {
  //           "type": 5,
  //           "name": "每满200减25券",
  //           "itemTag": null,
  //           "itemTagType": null,
  //           "freshmanExclusive": false
  //         }
  //       ],
  //       "goodRate": null,
  //       "heat": null,
  //       "repoCount": null,
  //       "scenePicUrl": "https://yanxuan-item.nosdn.127.net/3e45b7f32e57e1d0a2b15e7793fd720d.png",
  //       "freshman": false,
  //       "appExclusiveFlag": false,
  //       "accessTime": 0,
  //       "promotionFlag": 0,
  //       "specTag": null,
  //       "comments": [
  //         {
  //           "skuInfo": [
  //             "烟粉色",
  //             "女M"
  //           ],
  //           "frontUserName": "晶*****",
  //           "frontUserAvatar": "https://yanxuan.nosdn.127.net/5bb26e6d42b2fe336e132df671d1889b",
  //           "content": "第一次在严选上购买商品，给媳妇买了一双全包的棉拖鞋，抱着试试看的态度买的，今天收到后真心觉得质量非常好，内侧的毛很柔软，鞋面好像是那种麻材质的手感也不错，特意试了下鞋底，应该是防滑的，虽然价格稍微贵一点，但是自己觉得起码商品值这个价钱。以后看来有些东西可以转移到严选这边购买了。",
  //           "createTime": 1605847092993,
  //           "picList": [
  //             "https://yanxuan.nosdn.127.net/513c949f35570ce0c0d17c38e88176c6.jpg",
  //             "https://yanxuan.nosdn.127.net/a0895629649fc9efcd3ee8a71c6e70b1.jpg",
  //             "https://yanxuan.nosdn.127.net/e4fb8495771983e7deec7f205d3b9d35.jpg",
  //             "https://yanxuan.nosdn.127.net/93341a1fd32a7dc6796ebfa38219960a.jpg",
  //             "https://yanxuan.nosdn.127.net/0e1125a9bb9630b2cd8937878b55a756.jpg"
  //           ],
  //           "kfReplyTitle": null,
  //           "kfReplyContent": null,
  //           "memLevel": 4,
  //           "appendCommentVO": null,
  //           "star": 5
  //         }
  //       ],
  //       "promBanner": {
  //         "valid": true,
  //         "bannerType": 0,
  //         "promoTitle": "可用券",
  //         "promoSubTitle": "12.9 22点~12.12",
  //         "content": "每满200减25券",
  //         "bannerTitleUrl": "https://yanxuan.nosdn.127.net/d71e2460d062eaa21d5bdf97eba9da89.png",
  //         "bannerContentUrl": "https://yanxuan.nosdn.127.net/c168892ef76f29971032dc1c12613720.png",
  //         "styleType": 1,
  //         "timeType": 0,
  //         "iconUrl": null,
  //         "usualContent": [],
  //         "firstOrderType": 0,
  //         "firstOrderTitle": null
  //       },
  //       "promLogo": {
  //         "logoUrl": "https://yanxuan.nosdn.127.net/58d6fda500049ef9f3f0301ecf6e2229.png",
  //         "width": 108,
  //         "height": 108
  //       },
  //       "promDesc": null,
  //       "couponTag": null,
  //       "couponPrice": 42.87,
  //       "depositSwapped": false,
  //       "returnPrice": null,
  //       "limitedSingleProm": false
  //     },
  //     "pinItem": null,
  //     "id": 3992464
  //   },
  //   {
  //     "type": 1,
  //     "indexRcmdPic": null,
  //     "categoryItem": {
  //       "id": 1535011,
  //       "name": "远优于欧盟标准，纯牛奶 250 毫升*24盒",
  //       "categoryId": 109276003,
  //       "primaryPicUrl": "https://yanxuan-item.nosdn.127.net/22cfd602403ca6a026a439e08e3e3127.png",
  //       "listPicUrl": "https://yanxuan-item.nosdn.127.net/248a4839ff231fd737d676d1a3f35df1.png",
  //       "retailPrice": 88,
  //       "activityPrice": null,
  //       "soldOut": false,
  //       "few": false,
  //       "last": false,
  //       "simpleDesc": "原奶指标远优于欧盟标准",
  //       "simpleDescClose": false,
  //       "extraPrice": "",
  //       "newOnShelf": false,
  //       "forSale": false,
  //       "specification": null,
  //       "unShelf": false,
  //       "limitedFlag": false,
  //       "limitedTag": "年终底价",
  //       "productPlace": "",
  //       "itemTagList": [],
  //       "goodRate": null,
  //       "heat": null,
  //       "repoCount": null,
  //       "scenePicUrl": "https://yanxuan-item.nosdn.127.net/1fdbd160df259819513cb44ce87a9f11.jpg",
  //       "freshman": false,
  //       "appExclusiveFlag": false,
  //       "accessTime": 0,
  //       "promotionFlag": 0,
  //       "specTag": "限时购",
  //       "comments": [
  //         {
  //           "skuInfo": [
  //             "纯牛奶 12盒*2提"
  //           ],
  //           "frontUserName": "未****夏",
  //           "frontUserAvatar": "https://yanxuan.nosdn.127.net/8a4f27aab5caf51a5f7d0d96008b1263",
  //           "content": "第一次买，感觉不错啊！做了蛋糕哦！味道不错不错不错不错的！",
  //           "createTime": 1589447450472,
  //           "picList": [
  //             "https://yanxuan.nosdn.127.net/5ba45d32efb5e3a00145e5bd44fe2955.jpg"
  //           ],
  //           "kfReplyTitle": null,
  //           "kfReplyContent": null,
  //           "memLevel": 3,
  //           "appendCommentVO": null,
  //           "star": 5
  //         }
  //       ],
  //       "promBanner": {
  //         "valid": true,
  //         "bannerType": 0,
  //         "promoTitle": "0元",
  //         "promoSubTitle": null,
  //         "content": "首单全额返 下单立返88元",
  //         "bannerTitleUrl": "https://yanxuan.nosdn.127.net/d71e2460d062eaa21d5bdf97eba9da89.png",
  //         "bannerContentUrl": "https://yanxuan.nosdn.127.net/c168892ef76f29971032dc1c12613720.png",
  //         "styleType": 0,
  //         "timeType": 0,
  //         "iconUrl": null,
  //         "usualContent": [],
  //         "firstOrderType": 1,
  //         "firstOrderTitle": "0"
  //       },
  //       "promLogo": null,
  //       "promDesc": null,
  //       "couponTag": null,
  //       "couponPrice": null,
  //       "depositSwapped": false,
  //       "returnPrice": null,
  //       "limitedSingleProm": false
  //     },
  //     "pinItem": null,
  //     "id": 1535011
  //   },
  //   {
  //     "type": 2,
  //     "indexRcmdPic": null,
  //     "categoryItem": null,
  //     "pinItem": {
  //       "id": 2041158,
  //       "description": "把富士山美景背在身上",
  //       "categoryId": 109268000,
  //       "userNum": 2,
  //       "recentUsers": "[\"https://yanxuan.nosdn.127.net/452203287a0c23f1300802dd027b311e\",\"https://yanxuan.nosdn.127.net/bcd2b3377b7f2395ee087fcb0f058f05\"]",
  //       "picUrl": "https://yanxuan-item.nosdn.127.net/e3a69dcd4ef9a16da369dbbf88a6a1b6.jpg",
  //       "title": "大英博物馆 富士山美景 防水抽绳包",
  //       "itemId": 3988574,
  //       "price": 56,
  //       "originPrice": 79,
  //       "returnPrice": 0,
  //       "skuNum": 1,
  //       "joinUsers": 2711,
  //       "limitTime": false,
  //       "modeType": 2,
  //       "status": 0,
  //       "comments": [
  //         {
  //           "skuInfo": [
  //             "抽绳包"
  //           ],
  //           "frontUserName": "岁*****",
  //           "frontUserAvatar": "http://nos.netease.com/mail-online/6125142e20e05d4bb50ef8fd898d8d7f/mail180x180.jpg",
  //           "content": "还行吧……",
  //           "createTime": 1603966299616,
  //           "picList": null,
  //           "kfReplyTitle": null,
  //           "kfReplyContent": null,
  //           "memLevel": 5,
  //           "appendCommentVO": null,
  //           "star": 5
  //         }
  //       ]
  //     },
  //     "id": 3988574
  //   },
  //   {
  //     "type": 1,
  //     "indexRcmdPic": null,
  //     "categoryItem": {
  //       "id": 3993220,
  //       "name": "补充27种维生素，雅培小安素全营养配方粉",
  //       "categoryId": 109283000,
  //       "primaryPicUrl": "https://yanxuan-item.nosdn.127.net/6003bee5acd879584640eeda8033a62e.png",
  //       "listPicUrl": "https://yanxuan-item.nosdn.127.net/3ee6268f3d9595aff8c62912608d3aa5.png",
  //       "retailPrice": 239,
  //       "activityPrice": null,
  //       "soldOut": false,
  //       "few": false,
  //       "last": false,
  //       "simpleDesc": "每天2-3杯，全面营养守护成长",
  //       "simpleDescClose": false,
  //       "extraPrice": "",
  //       "newOnShelf": false,
  //       "forSale": false,
  //       "specification": null,
  //       "unShelf": false,
  //       "limitedFlag": false,
  //       "limitedTag": "",
  //       "productPlace": "",
  //       "itemTagList": [],
  //       "goodRate": null,
  //       "heat": null,
  //       "repoCount": null,
  //       "scenePicUrl": "https://yanxuan-item.nosdn.127.net/8d81114918658ba8f42dec2d7fb56bb5.png",
  //       "freshman": false,
  //       "appExclusiveFlag": false,
  //       "accessTime": 0,
  //       "promotionFlag": 0,
  //       "specTag": null,
  //       "comments": [
  //         {
  //           "skuInfo": [
  //             "小安素罐装"
  //           ],
  //           "frontUserName": "1****1",
  //           "frontUserAvatar": null,
  //           "content": "一直买的还这款，宝贝不错！",
  //           "createTime": 1604998166995,
  //           "picList": [
  //             "https://yanxuan.nosdn.127.net/619554e79b1f0b969816c63b0aee87bf.jpg",
  //             "https://yanxuan.nosdn.127.net/c8ae26572c703b06e26eb0f5044de3d8.jpg"
  //           ],
  //           "kfReplyTitle": null,
  //           "kfReplyContent": null,
  //           "memLevel": 3,
  //           "appendCommentVO": null,
  //           "star": 5
  //         }
  //       ],
  //       "promBanner": {
  //         "valid": false,
  //         "bannerType": 0,
  //         "promoTitle": null,
  //         "promoSubTitle": null,
  //         "content": null,
  //         "bannerTitleUrl": "https://yanxuan.nosdn.127.net/d71e2460d062eaa21d5bdf97eba9da89.png",
  //         "bannerContentUrl": "https://yanxuan.nosdn.127.net/c168892ef76f29971032dc1c12613720.png",
  //         "styleType": 1,
  //         "timeType": 0,
  //         "iconUrl": null,
  //         "usualContent": [],
  //         "firstOrderType": 0,
  //         "firstOrderTitle": null
  //       },
  //       "promLogo": null,
  //       "promDesc": null,
  //       "couponTag": null,
  //       "couponPrice": null,
  //       "depositSwapped": false,
  //       "returnPrice": null,
  //       "limitedSingleProm": false
  //     },
  //     "pinItem": null,
  //     "id": 3993220
  //   },
  //   {
  //     "type": 1,
  //     "indexRcmdPic": null,
  //     "categoryItem": {
  //       "id": 1354000,
  //       "name": "移动话费 多种面额充值",
  //       "categoryId": 1025000,
  //       "primaryPicUrl": "https://yanxuan-item.nosdn.127.net/d3fa5c27c960809f119e42dab99fed4d.png",
  //       "listPicUrl": "https://yanxuan-item.nosdn.127.net/bae14aeb1c6136e1a67b5d0db85b94dd.png",
  //       "retailPrice": 49.9,
  //       "activityPrice": null,
  //       "soldOut": false,
  //       "few": false,
  //       "last": false,
  //       "simpleDesc": "快速充值，便捷生活",
  //       "simpleDescClose": false,
  //       "extraPrice": "",
  //       "newOnShelf": false,
  //       "forSale": false,
  //       "specification": null,
  //       "unShelf": false,
  //       "limitedFlag": false,
  //       "limitedTag": "",
  //       "productPlace": "",
  //       "itemTagList": [
  //         {
  //           "type": 0,
  //           "name": "仅支持专属话费优惠券",
  //           "itemTag": null,
  //           "itemTagType": null,
  //           "freshmanExclusive": false
  //         }
  //       ],
  //       "goodRate": null,
  //       "heat": null,
  //       "repoCount": null,
  //       "scenePicUrl": "https://yanxuan-item.nosdn.127.net/775a6be4b5fac254337c6406a89b7b28.jpg",
  //       "freshman": false,
  //       "appExclusiveFlag": false,
  //       "accessTime": 0,
  //       "promotionFlag": 0,
  //       "specTag": null,
  //       "comments": [
  //         {
  //           "skuInfo": [
  //             "湖南",
  //             "50"
  //           ],
  //           "frontUserName": "小****物",
  //           "frontUserAvatar": "https://yanxuan.nosdn.127.net/d55825d6ee7a71e5d1155e9737ad3ecd",
  //           "content": "超级快到账",
  //           "createTime": 1583021600253,
  //           "picList": [
  //             "https://yanxuan.nosdn.127.net/8b3b1c1095d4008c228e2b07cfe25d3f.jpg",
  //             "https://yanxuan.nosdn.127.net/343f63d65d32376138ea1ca60d0e867d.jpg",
  //             "https://yanxuan.nosdn.127.net/a1ac121d185facd3442dc2d9ccd7b04b.jpg",
  //             "https://yanxuan.nosdn.127.net/5ed50f7e63d6f65265c2a1a900c08930.jpg",
  //             "https://yanxuan.nosdn.127.net/a32bd4e2ea442592880fab66a048b51e.jpg"
  //           ],
  //           "kfReplyTitle": null,
  //           "kfReplyContent": null,
  //           "memLevel": 5,
  //           "appendCommentVO": null,
  //           "star": 5
  //         }
  //       ],
  //       "promBanner": {
  //         "valid": false,
  //         "bannerType": 0,
  //         "promoTitle": null,
  //         "promoSubTitle": null,
  //         "content": null,
  //         "bannerTitleUrl": "https://yanxuan.nosdn.127.net/d71e2460d062eaa21d5bdf97eba9da89.png",
  //         "bannerContentUrl": "https://yanxuan.nosdn.127.net/c168892ef76f29971032dc1c12613720.png",
  //         "styleType": 1,
  //         "timeType": 0,
  //         "iconUrl": null,
  //         "usualContent": [],
  //         "firstOrderType": 0,
  //         "firstOrderTitle": null
  //       },
  //       "promLogo": null,
  //       "promDesc": null,
  //       "couponTag": null,
  //       "couponPrice": null,
  //       "depositSwapped": false,
  //       "returnPrice": null,
  //       "limitedSingleProm": false
  //     },
  //     "pinItem": null,
  //     "id": 1354000
  //   },
  //   {
  //     "type": 2,
  //     "indexRcmdPic": null,
  //     "categoryItem": null,
  //     "pinItem": {
  //       "id": 2041159,
  //       "description": "遮阳防晒 晴雨两用",
  //       "categoryId": 109268000,
  //       "userNum": 2,
  //       "recentUsers": "[\"https://yanxuan.nosdn.127.net/0234ac0339a2d6502368c56b0d443c52\",\"https://yanxuan.nosdn.127.net/0c7d5b84cfcdb93359a63d5b1db96514\"]",
  //       "picUrl": "https://yanxuan-item.nosdn.127.net/911bacfd064ce2f4eec8e116f309cdb6.jpg",
  //       "title": "大英博物馆 爱丽丝花式三折晴雨两用伞",
  //       "itemId": 3989985,
  //       "price": 75,
  //       "originPrice": 99,
  //       "returnPrice": 0,
  //       "skuNum": 1,
  //       "joinUsers": 2908,
  //       "limitTime": false,
  //       "modeType": 2,
  //       "status": 0,
  //       "comments": [
  //         {
  //           "skuInfo": [
  //             "爱丽丝"
  //           ],
  //           "frontUserName": "w****3",
  //           "frontUserAvatar": null,
  //           "content": "还没用呢用过再评吧",
  //           "createTime": 1599467446050,
  //           "picList": null,
  //           "kfReplyTitle": null,
  //           "kfReplyContent": null,
  //           "memLevel": 5,
  //           "appendCommentVO": null,
  //           "star": 5
  //         }
  //       ]
  //     },
  //     "id": 3989985
  //   },
  //   {
  //     "type": 1,
  //     "indexRcmdPic": null,
  //     "categoryItem": {
  //       "id": 3383008,
  //       "name": "告别啃食尴尬，秘制无骨凤爪 108克",
  //       "categoryId": 1035003,
  //       "primaryPicUrl": "https://yanxuan-item.nosdn.127.net/488a81259dec9371232b37d133e1bbb8.png",
  //       "listPicUrl": "https://yanxuan-item.nosdn.127.net/91b067de134dbd8adbdb12f2eb41ae4d.png",
  //       "retailPrice": 22,
  //       "activityPrice": "19.9",
  //       "soldOut": false,
  //       "few": false,
  //       "last": false,
  //       "simpleDesc": "肉嘟嘟，大口吃",
  //       "simpleDescClose": false,
  //       "extraPrice": "",
  //       "newOnShelf": false,
  //       "forSale": false,
  //       "specification": null,
  //       "unShelf": false,
  //       "limitedFlag": true,
  //       "limitedTag": "年终底价",
  //       "productPlace": "2个口味",
  //       "itemTagList": [
  //         {
  //           "type": 107,
  //           "name": "年终底价",
  //           "itemTag": "XIAN_SHI_LIST",
  //           "itemTagType": null,
  //           "freshmanExclusive": false
  //         },
  //         {
  //           "type": 5,
  //           "name": "每满200减25券",
  //           "itemTag": null,
  //           "itemTagType": null,
  //           "freshmanExclusive": false
  //         }
  //       ],
  //       "goodRate": null,
  //       "heat": null,
  //       "repoCount": null,
  //       "scenePicUrl": "https://yanxuan-item.nosdn.127.net/a046bcc0ed86af327d5e5516ef6f1c66.jpg",
  //       "freshman": false,
  //       "appExclusiveFlag": false,
  //       "accessTime": 0,
  //       "promotionFlag": 0,
  //       "specTag": "限时购",
  //       "comments": [
  //         {
  //           "skuInfo": [
  //             "泡椒味 108克*2+藤椒味 108克*2"
  //           ],
  //           "frontUserName": "大****唐",
  //           "frontUserAvatar": "http://q.qlogo.cn/qqapp/1104949895/CE8A59AC74F1F6A37C0F639F0ACDA442/100",
  //           "content": "超级好吃 藤椒和泡椒都各有特色 吃着会上瘾的鸡爪子，还不用啃骨头，太豪横了！过瘾！！",
  //           "createTime": 1586879958516,
  //           "picList": [
  //             "https://yanxuan.nosdn.127.net/85ecb0c8575cbd8f56b0f236b1dd810c.jpg",
  //             "https://yanxuan.nosdn.127.net/7381ebabb220f07e6f8e2138a396aa34.jpg",
  //             "https://yanxuan.nosdn.127.net/ee00475852c6de29c328aa279e87fa0a.jpg",
  //             "https://yanxuan.nosdn.127.net/a6fb8ec892c315fa62913074eb1f8eb2.jpg",
  //             "https://yanxuan.nosdn.127.net/2a43b16e5fe343d08102b6bf187978b9.jpg"
  //           ],
  //           "kfReplyTitle": null,
  //           "kfReplyContent": null,
  //           "memLevel": 2,
  //           "appendCommentVO": null,
  //           "star": 5
  //         }
  //       ],
  //       "promBanner": {
  //         "valid": true,
  //         "bannerType": 0,
  //         "promoTitle": "年终底价",
  //         "promoSubTitle": "¥19.9起",
  //         "content": "限6471件 仅剩1天",
  //         "bannerTitleUrl": "https://yanxuan.nosdn.127.net/d71e2460d062eaa21d5bdf97eba9da89.png",
  //         "bannerContentUrl": "https://yanxuan.nosdn.127.net/c168892ef76f29971032dc1c12613720.png",
  //         "styleType": 1,
  //         "timeType": 0,
  //         "iconUrl": null,
  //         "usualContent": [],
  //         "firstOrderType": 0,
  //         "firstOrderTitle": null
  //       },
  //       "promLogo": {
  //         "logoUrl": "https://yanxuan.nosdn.127.net/58d6fda500049ef9f3f0301ecf6e2229.png",
  //         "width": 108,
  //         "height": 108
  //       },
  //       "promDesc": null,
  //       "couponTag": null,
  //       "couponPrice": 17.41,
  //       "depositSwapped": false,
  //       "returnPrice": null,
  //       "limitedSingleProm": true
  //     },
  //     "pinItem": null,
  //     "id": 3383008
  //   }
  // ]
