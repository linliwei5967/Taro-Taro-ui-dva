import {Request} from '../../utils/request'

// 获取首页顶部轮播项
export async function getBannerList(params) {
  return Request({url:'/cloud-vip-net/banners/app-list', method: 'get', data: params});
}

// 获取首页精选项
export async function getRecommendList(params) {
  return Request({url:'/cloud-vip-net/agreement/recommend/app-list', method: 'get', data: params});
}

