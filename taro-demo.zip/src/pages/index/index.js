import Taro, { eventCenter } from '@tarojs/taro'
import React, { Component } from 'react'
import {View, Text, Swiper, SwiperItem, Image, Slider} from '@tarojs/components'
import {AtButton, AtList, AtListItem} from 'taro-ui'
import Banner from './banner'
import Recommend from './recommend'
import "taro-ui/dist/style/components/button.scss" // 按需引入
import './index.scss'
import {connect} from "react-redux";

@connect(({ indexModel })=>{
  const { data } = indexModel
  return {
    data
  }
})
export default class Index extends Component {
  constructor (props) {
    super(props)
    this.state = {
      current: 1,
      duration: 500,
      interval: 5000,
      isCircular: true,
      isAutoplay: true,
      hasIndicatorDots: true,
      // imgUrls: [
      //   'https://img10.360buyimg.com/babel/s700x360_jfs/t25855/203/725883724/96703/5a598a0f/5b7a22e1Nfd6ba344.jpg!q90!cc_350x180',
      //   'https://img11.360buyimg.com/babel/s700x360_jfs/t1/4776/39/2280/143162/5b9642a5E83bcda10/d93064343eb12276.jpg!q90!cc_350x180',
      //   'https://img14.360buyimg.com/babel/s700x360_jfs/t1/4099/12/2578/101668/5b971b4bE65ae279d/89dd1764797acfd9.jpg!q90!cc_350x180'
      // ]
      imgUrls: [
        'https://img10.360buyimg.com/babel/s700x360_jfs/t25855/203/725883724/96703/5a598a0f/5b7a22e1Nfd6ba344.jpg!q90!cc_350x180',
        'https://img11.360buyimg.com/babel/s700x360_jfs/t1/4776/39/2280/143162/5b9642a5E83bcda10/d93064343eb12276.jpg!q90!cc_350x180',
        'https://img14.360buyimg.com/babel/s700x360_jfs/t1/4099/12/2578/101668/5b971b4bE65ae279d/89dd1764797acfd9.jpg!q90!cc_350x180'
      ]
    }
  }
  componentWillMount () {}

  componentDidMount () { }

  componentWillUnmount () { }

  componentDidShow () { }

  componentDidHide () { }

  handleNavigate = () => {
    Taro.navigateTo({
      url: '/pages/detail/index'
    })
  }

  render () {
    const {  } = this.state
    const { data } = this.props
    return (
      <View className='index-container'>
        <View className='doc-body'>
          <View className='panel'>
            <View className='panel__content swiper-container'>
              <View className='example-item'>
                <Banner />  {/* 顶部轮播图 */}
              </View>
              {data}
            </View>
            <View className='panel__title no-strong at-row'>
                <View className='at-col at-col-10 title-1'>精选服务</View>
                <View className='at-col at-col-2'>全部&gt;</View>
            </View>
            <View className='panel__content'>
              <View className='example-item'>
                {/* 精选服务 协议*/}
                <Recommend
                  api={'/cloud-vip-net/agreement/recommend/app-list'}
                  params={{recommendType: "1",}}
                />
              </View>
            </View>
            <View className='panel__title no-strong at-row'>
              <View className='at-col at-col-10 title-1'>精选会员卡</View>
              <View className='at-col at-col-2'>全部&gt;</View>
            </View>
            <View className='panel__content'>
              <View className='example-item'>
                {/* 精选会员卡 会员卡*/}
                <Recommend
                  params={{recommendType: 2,}}
                />
              </View>
            </View>
            <View className='panel__title no-strong at-row'>
              <View className='at-col at-col-10 title-1'>精选产品</View>
              <View className='at-col at-col-2'>全部&gt;</View>
            </View>
            <View className='panel__content'>
              <View className='example-item'>
                {/* 精选产品 单服务产品*/}
                <Recommend
                  params={{recommendType: 4,}}
                />
              </View>
            </View>
          </View>
        </View>
      </View>
    )
  }
}
