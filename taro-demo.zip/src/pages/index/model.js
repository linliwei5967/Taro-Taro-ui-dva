import {getBannerList, getRecommendList} from "./services";

export default {
  namespace: 'indexModel',
  state: {

  },
  effects: {
    // 获取首页轮播项
    * getBannerList({payload}, {call, put}) {
      const res = yield call(getBannerList, payload)
      const {data = {}} = res || {}
      return res
    },
    // 获取首页精选项
    * getRecommendList({payload}, {call, put}) {
      const res = yield call(getRecommendList, payload)
      const {data = {}} = res || {}
      // yield put({
      //   type: 'updateState',
      //   payload: {data: data[0].areaName || []},
      // });
      return res
    },
  },
  reducers: {
    updateState(state, {payload}) {
      return {
        ...state,
        ...payload,
      };
    },
  },
}
